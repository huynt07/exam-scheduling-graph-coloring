/**
 * main.js — Điểm vào của giao diện, nối các module thành một luồng (người E).
 *
 * Luồng: dữ liệu (nhập tay hoặc file) → buildGraph → tô màu → buildSchedule → kiểm tra → hiển thị.
 * Mọi lời gọi module đặt trong try/catch; lỗi được hiện ngay trên trang.
 * Ứng dụng KHÔNG nạp sẵn dữ liệu nào: bảng nhập để trống khi mở.
 */
import 'bootstrap/dist/css/bootstrap.min.css';
import '../../css/style.css';
import $ from 'jquery';

import { validateRegistrations, summarizeRegistrations, normalizeHeader } from '../core/dataLoader.js';
import { buildGraph, graphStats } from '../core/graphBuilder.js';
import { welshPowell } from '../core/welshPowell.js';
import { dsatur } from '../core/dsatur.js';
import { isValidColoring, countColors, checkScheduleByStudent, checkRooms } from '../core/validator.js';
import { compareAlgorithms } from '../core/compare.js';
import { lookupStudent } from '../core/lookup.js';
import { buildSchedule, slotSummary } from '../core/scheduler.js';
import { defaultConfig, validateConfig, configToJson, configFromJson } from '../core/constraints.js';
import { exportSchedule } from '../core/exporter.js';
import { loadRegistrations } from './fileLoader.js';
import { drawGraph } from './visualizer.js';
import {
  showAlert, renderSummary, renderLegend, renderSchedule, renderWarnings, renderComparison,
  comparisonCsv, renderSlotBalance, renderLookup, downloadBlob,
} from './statsPanel.js';

const ALGOS = {
  welshPowell: { name: 'Welsh-Powell', run: welshPowell },
  dsatur: { name: 'DSATUR', run: dsatur },
};
const CONFIG_KEY = 'lichThiToMau.config';

/** Trạng thái của trang. */
const state = {
  registrations: null,
  graph: null,
  /** @type {{algoId: string, colors: Map<string, number>, steps: object[]}[]} */
  runs: [],
  schedule: null,
  comparison: null,
  step: { runIndex: 0, index: 0 },
};

/* ---------------- Tab ---------------- */
$('[data-tabs]').each(function setupTabs() {
  const $nav = $(this);
  const $panes = $nav.closest('.card').find('.tab-pane-x');
  $nav.on('click', '[data-tab]', function onTab() {
    const tab = $(this).data('tab');
    $nav.find('.nav-link').removeClass('active');
    $(this).addClass('active');
    $panes.each(function toggle() {
      // Chỉ bật/tắt các pane thuộc cùng nhóm tab với thanh tab này.
      if ($nav.find(`[data-tab="${$(this).data('pane')}"]`).length) $(this).toggleClass('d-none', $(this).data('pane') !== tab);
    });
    if (tab === 'graph') redrawGraph();
  });
});

/* ---------------- 1. Nhập trực tiếp ---------------- */
const $manualBody = $('#manualTable tbody');

function addRow(studentId = '', courseId = '') {
  const $tr = $('<tr>').append(
    $('<td>').addClass('text-muted small row-idx'),
    $('<td>').append($('<input>').addClass('form-control form-control-sm in-student').val(studentId)),
    $('<td>').append($('<input>').addClass('form-control form-control-sm in-course').val(courseId)),
    $('<td>').append($('<button type="button">').addClass('btn btn-sm btn-link text-danger del-row').attr('title', 'Xóa dòng').text('✕')),
  );
  $manualBody.append($tr);
  renumber();
  return $tr;
}
function renumber() {
  $manualBody.find('tr').each((i, tr) => $(tr).find('.row-idx').text(i + 1));
}
function manualRows() {
  return $manualBody.find('tr').map((_, tr) => ({
    studentId: $(tr).find('.in-student').val(),
    courseId: $(tr).find('.in-course').val(),
  })).get();
}

for (let i = 0; i < 5; i++) addRow(); // 5 dòng trống, không có dữ liệu mẫu
$('#addRow').on('click', () => addRow().find('.in-student').trigger('focus'));
$('#addRows').on('click', () => { for (let i = 0; i < 10; i++) addRow(); });
$('#clearRows').on('click', () => {
  $manualBody.empty();
  for (let i = 0; i < 5; i++) addRow();
});
$manualBody.on('click', '.del-row', function onDelete() {
  $(this).closest('tr').remove();
  if ($manualBody.find('tr').length === 0) addRow();
  renumber();
});

// Dán nhiều dòng từ Excel (cách nhau bởi tab) hoặc từ văn bản (dấu phẩy, chấm phẩy).
$manualBody.on('paste', 'input', function onPaste(event) {
  const text = event.originalEvent.clipboardData?.getData('text') ?? '';
  if (!/[\n\t]/.test(text)) return; // dán một ô bình thường
  event.preventDefault();
  let lines = text.split(/\r\n|\n|\r/).filter((l) => l.trim() !== '');
  const split = (l) => l.split(/\t|;|,/).map((s) => s.trim());
  // Bỏ dòng tiêu đề nếu có.
  if (lines.length && ['studentid', 'mssv', 'masv', 'masinhvien'].includes(normalizeHeader(split(lines[0])[0]))) lines = lines.slice(1);
  let $tr = $(this).closest('tr');
  for (const line of lines) {
    const [s = '', c = ''] = split(line);
    if (!$tr.length) $tr = addRow();
    $tr.find('.in-student').val(s);
    $tr.find('.in-course').val(c);
    $tr = $tr.next('tr');
  }
  renumber();
});

$('#useManual').on('click', () => {
  try {
    setData(validateRegistrations(manualRows()), 'Nhập trực tiếp');
  } catch (err) {
    failData(err);
  }
});

/* ---------------- 1. Tải file ---------------- */
$('#fileInput').on('change', async (event) => {
  const file = event.target.files[0];
  if (!file) return;
  showAlert($('#dataMessage'), 'info', `Đang đọc ${file.name}...`);
  try {
    setData(await loadRegistrations(file), `File ${file.name}`);
  } catch (err) {
    failData(err);
  }
});

function setData(registrations, source) {
  state.registrations = registrations;
  state.graph = buildGraph(registrations);
  const summary = summarizeRegistrations(registrations);
  showAlert($('#dataMessage'), 'success', `Đã nhận ${summary.rows} dòng đăng ký hợp lệ. Bấm “Xếp lịch thi” để chạy.`);
  renderSummary($('#dataSummary'), summary, graphStats(state.graph), source);
  $('#run').prop('disabled', false);
  $('#results').addClass('d-none');
}
function failData(err) {
  state.registrations = null;
  state.graph = null;
  $('#run').prop('disabled', true);
  $('#dataSummary').empty();
  $('#results').addClass('d-none');
  showAlert($('#dataMessage'), 'danger', err.message || String(err));
}

/* ---------------- 2. Cấu hình ---------------- */
function nextMonday() {
  const d = new Date();
  d.setDate(d.getDate() + (((8 - d.getDay()) % 7) || 7));
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
function fillConfigForm(cfg) {
  $('#cfgStart').val(cfg.startDate);
  $('#cfgSlots').val(cfg.slotsPerDay);
  $('#cfgTimes').val(cfg.slotTimes.join(', '));
  $('#cfgMax').val(cfg.maxExamsPerDay ?? '');
  $('#cfgRooms').val(cfg.rooms.map((r) => `${r.id}, ${r.capacity}`).join('\n'));
  $('#cfgHolidays').val(cfg.holidays.join(', '));
  $('#cfgSunday').prop('checked', cfg.skipSundays);
}
/** Đọc form thành đối tượng cấu hình (chưa kiểm tra). */
function readConfigForm() {
  const rooms = String($('#cfgRooms').val())
    .split(/\r\n|\n|\r/)
    .map((l) => l.trim())
    .filter(Boolean)
    .map((l) => {
      const parts = l.split(/[\s,;:]+/).filter(Boolean);
      return { id: parts[0], capacity: parts.length > 1 ? Number(parts[1]) : NaN };
    });
  return {
    startDate: String($('#cfgStart').val()),
    slotsPerDay: Number($('#cfgSlots').val()),
    slotTimes: String($('#cfgTimes').val()).split(/[,;\s]+/).filter(Boolean),
    rooms,
    holidays: String($('#cfgHolidays').val()).split(/[,;\s]+/).filter(Boolean),
    skipSundays: $('#cfgSunday').prop('checked'),
    maxExamsPerDay: $('#cfgMax').val() === '' ? null : Number($('#cfgMax').val()),
  };
}
function saveConfigLocal(cfg) {
  try { localStorage.setItem(CONFIG_KEY, configToJson(cfg)); } catch { /* trình duyệt chặn: bỏ qua */ }
}
(function initConfig() {
  let cfg = { ...defaultConfig(), startDate: nextMonday() };
  try {
    const saved = localStorage.getItem(CONFIG_KEY);
    if (saved) cfg = configFromJson(saved);
  } catch { /* cấu hình cũ hỏng hoặc không đọc được: dùng mặc định */ }
  fillConfigForm(cfg);
})();

$('#saveConfig').on('click', () => {
  try {
    const cfg = validateConfig(readConfigForm());
    saveConfigLocal(cfg);
    downloadBlob(new Blob([configToJson(cfg)], { type: 'application/json' }), 'cauhinh-lichthi.json');
    showAlert($('#configMessage'), 'success', 'Đã lưu cấu hình.');
  } catch (err) {
    showAlert($('#configMessage'), 'danger', err.message);
  }
});
$('#loadConfig').on('change', async (event) => {
  const file = event.target.files[0];
  event.target.value = '';
  if (!file) return;
  try {
    const cfg = configFromJson(await file.text());
    fillConfigForm(cfg);
    saveConfigLocal(cfg);
    showAlert($('#configMessage'), 'success', `Đã mở cấu hình từ ${file.name}.`);
  } catch (err) {
    showAlert($('#configMessage'), 'danger', err.message);
  }
});

/* ---------------- 3. Chạy ---------------- */
$('#run').on('click', () => {
  $('#runMessage').empty();
  $('#configMessage').empty();
  if (!state.graph) return;

  let cfg;
  try {
    cfg = validateConfig(readConfigForm());
    saveConfigLocal(cfg);
  } catch (err) {
    showAlert($('#configMessage'), 'danger', err.message);
    return;
  }

  try {
    const choice = String($('#algo').val());
    const repeat = Math.max(1, Math.min(1000, Number($('#repeat').val()) || 20));
    const ids = choice === 'both' ? ['welshPowell', 'dsatur'] : [choice];

    // Chạy lại từng thuật toán một lần với mảng steps để xem từng bước.
    state.runs = ids.map((algoId) => {
      const steps = [];
      const colors = ALGOS[algoId].run(state.graph, steps);
      const check = isValidColoring(state.graph, colors);
      if (!check.valid) throw new Error(`${ALGOS[algoId].name} cho kết quả không hợp lệ (lỗi chương trình).`);
      return { algoId, colors, steps };
    });
    state.comparison = choice === 'both' ? compareAlgorithms(state.graph, { repeat }) : null;

    // Lịch dùng kết quả ít màu hơn (bằng nhau thì DSATUR).
    const chosen = [...state.runs].sort((a, b) => countColors(a.colors) - countColors(b.colors) || (a.algoId === 'dsatur' ? -1 : 1))[0];
    const result = buildSchedule(chosen.colors, state.registrations, cfg);
    state.schedule = result.schedule;

    const byStudent = checkScheduleByStudent(result.schedule, state.registrations);
    const roomCheck = checkRooms(result.schedule, cfg.rooms);

    renderAll(result, chosen, byStudent, roomCheck, repeat);
    $('#results').removeClass('d-none');
    showAlert(
      $('#runMessage'), 'success',
      `Xong: ${ALGOS[chosen.algoId].name} dùng ${countColors(chosen.colors)} màu → ${result.periods} ca thi trong ${result.days} ngày.`,
    );
  } catch (err) {
    $('#results').addClass('d-none');
    showAlert($('#runMessage'), 'danger', err.message || String(err));
  }
});

function renderAll(result, chosen, byStudent, roomCheck, repeat) {
  // Kết quả kiểm tra lịch.
  const lines = [];
  if (byStudent.valid) lines.push('✔ Không sinh viên nào bị trùng ca (đã kiểm tra theo từng sinh viên).');
  else lines.push(`✘ Có ${byStudent.conflicts.length} trường hợp trùng ca, ${byStudent.missing.length} môn thiếu trong lịch.`);
  lines.push(roomCheck.valid ? '✔ Không phòng nào bị dùng trùng hoặc vượt sức chứa.' : `✘ ${roomCheck.problems.join(' ')}`);
  lines.push(`Lịch được xếp từ kết quả của ${ALGOS[chosen.algoId].name}.`);
  showAlert($('#checkResult'), byStudent.valid && roomCheck.valid ? 'success' : 'danger', lines.join('\n'));

  renderWarnings($('#warnings'), result.warnings);
  renderSchedule($('#scheduleBody'), result.schedule);
  renderSlotBalance($('#slotBalance'), slotSummary(result.schedule), result);

  if (state.comparison) {
    renderComparison($('#comparison'), state.comparison, repeat);
    $('#exportCompare').removeClass('d-none');
  } else {
    showAlert($('#comparison'), 'info', 'Chọn “Chạy cả hai và so sánh” để xem bảng so sánh Welsh-Powell và DSATUR.');
    $('#exportCompare').addClass('d-none');
  }

  // Chế độ từng bước: mặc định hiện kết quả cuối của thuật toán đã dùng cho lịch.
  const $sel = $('#stepAlgo').empty();
  state.runs.forEach((r, i) => $sel.append($('<option>').val(i).text(ALGOS[r.algoId].name)));
  state.step.runIndex = state.runs.indexOf(chosen);
  $sel.val(state.step.runIndex);
  state.step.index = chosen.steps.length;
  $('#lookupResult').empty();
  redrawGraph();
}

/* ---------------- Đồ thị và từng bước ---------------- */
function redrawGraph() {
  const run = state.runs[state.step.runIndex];
  if (!run || $('#graphCanvas').is(':hidden')) return;
  const k = state.step.index;
  const partial = new Map(run.steps.slice(0, k).map((s) => [s.course, s.color]));
  const last = k > 0 ? run.steps[k - 1] : null;
  drawGraph(state.graph, partial, $('#graphCanvas')[0], { highlight: last ? last.course : null });
  renderLegend($('#legend'), partial);
  let info = `Bước ${k}/${run.steps.length}`;
  if (last) {
    info += `: tô ${last.course} màu ${last.color}`;
    if (last.saturation !== undefined) info += ` (độ bão hòa ${last.saturation})`;
  }
  $('#stepInfo').text(info);
}
$('#stepAlgo').on('change', function onAlgo() {
  state.step.runIndex = Number($(this).val());
  state.step.index = state.runs[state.step.runIndex].steps.length;
  redrawGraph();
});
$('#stepReset').on('click', () => { state.step.index = 0; redrawGraph(); });
$('#stepPrev').on('click', () => { state.step.index = Math.max(0, state.step.index - 1); redrawGraph(); });
$('#stepNext').on('click', () => {
  const run = state.runs[state.step.runIndex];
  if (run) state.step.index = Math.min(run.steps.length, state.step.index + 1);
  redrawGraph();
});
$('#stepEnd').on('click', () => {
  const run = state.runs[state.step.runIndex];
  if (run) state.step.index = run.steps.length;
  redrawGraph();
});
let resizeTimer = null;
$(window).on('resize', () => {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(redrawGraph, 150);
});

/* ---------------- Xuất file, tra cứu ---------------- */
async function doExport(format) {
  try {
    const blob = await exportSchedule(state.schedule, format);
    downloadBlob(blob, `LichThi.${format}`);
  } catch (err) {
    showAlert($('#warnings'), 'danger', err.message);
  }
}
$('#exportXlsx').on('click', () => doExport('xlsx'));
$('#exportCsv').on('click', () => doExport('csv'));
$('#exportCompare').on('click', () => {
  if (state.comparison) downloadBlob(new Blob([comparisonCsv(state.comparison)], { type: 'text/csv' }), 'SoSanh.csv');
});

$('#lookupForm').on('submit', (event) => {
  event.preventDefault();
  const id = String($('#lookupInput').val());
  try {
    renderLookup($('#lookupResult'), id, lookupStudent(state.schedule, state.registrations, id));
  } catch (err) {
    showAlert($('#lookupResult'), 'warning', err.message);
  }
});

/* ---------------- Lỗi ngoài dự kiến ---------------- */
window.addEventListener('error', (e) => showAlert($('#globalError'), 'danger', `Lỗi chương trình: ${e.message}`));
window.addEventListener('unhandledrejection', (e) => showAlert($('#globalError'), 'danger', `Lỗi chương trình: ${e.reason?.message ?? e.reason}`));
