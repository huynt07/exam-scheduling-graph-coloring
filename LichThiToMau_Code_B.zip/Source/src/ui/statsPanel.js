/**
 * statsPanel.js — Hiển thị bảng lịch thi, bảng so sánh, thống kê ca, cảnh báo, tra cứu (người E).
 *
 * Mọi chữ lấy từ dữ liệu người dùng đều được chèn bằng .text() của jQuery để không bị
 * hiểu nhầm thành HTML.
 */
import $ from 'jquery';
import { colorFor, legendItems } from './visualizer.js';
import { improvementPercent } from '../core/compare.js';

/** Tạo một ô bảng với nội dung chữ. */
const td = (text, cls = '') => $('<td>').addClass(cls).text(text);
const fmtMs = (ms) => (ms < 0.01 ? '< 0,01' : ms.toFixed(ms < 1 ? 3 : 2).replace('.', ','));
const fmtPct = (x) => `${x.toFixed(1).replace('.', ',')}%`;
const viDate = (iso) => {
  const [y, m, d] = iso.split('-');
  return `${d}/${m}/${y}`;
};

/**
 * Hiện thông báo trong một vùng (thành công, cảnh báo, lỗi).
 * @param {JQuery} $el
 * @param {'success'|'warning'|'danger'|'info'} kind
 * @param {string} message  có thể nhiều dòng
 */
export function showAlert($el, kind, message) {
  $el.empty().append($('<div>').addClass(`alert alert-${kind} mb-0 pre-line`).text(message));
}

/**
 * Tóm tắt dữ liệu và đồ thị sau khi nhập.
 * @param {JQuery} $el
 * @param {{students: number, courses: number, rows: number}} summary
 * @param {{vertices: number, edges: number, maxDegree: number, isolated: number, density: number}} stats
 * @param {string} source
 */
export function renderSummary($el, summary, stats, source) {
  const items = [
    ['Nguồn', source],
    ['Số dòng đăng ký', summary.rows],
    ['Số sinh viên', summary.students],
    ['Số môn (đỉnh)', summary.courses],
    ['Số cặp môn xung đột (cạnh)', stats.edges],
    ['Bậc lớn nhất Δ', stats.maxDegree],
    ['Môn không trùng SV với môn nào', stats.isolated],
  ];
  const $row = $('<div>').addClass('row g-2');
  for (const [k, v] of items) {
    $row.append($('<div>').addClass('col-6 col-md-3').append(
      $('<div>').addClass('stat-box').append($('<div>').addClass('stat-label').text(k), $('<div>').addClass('stat-value').text(v)),
    ));
  }
  $el.empty().append($row);
}

/**
 * Chú thích màu dưới đồ thị.
 * @param {JQuery} $el
 * @param {Map<string, number>} colors
 */
export function renderLegend($el, colors) {
  $el.empty();
  for (const { color, css, count } of legendItems(colors)) {
    $el.append($('<span>').addClass('legend-item').append(
      $('<span>').addClass('legend-swatch').css('background', css),
      $('<span>').text(`Màu ${color} (${count} môn)`),
    ));
  }
}

/**
 * Bảng lịch thi: mỗi dòng một môn; các môn cùng ca nằm liền nhau.
 * @param {JQuery} $tbody
 * @param {import('../core/scheduler.js').ScheduleEntry[]} schedule
 */
export function renderSchedule($tbody, schedule) {
  $tbody.empty();
  let lastPeriod = -1;
  for (const e of schedule) {
    const $tr = $('<tr>');
    if (e.period !== lastPeriod) $tr.addClass('period-start');
    lastPeriod = e.period;
    $tr.append(
      td(viDate(e.date)),
      td(`Ca ${e.slot}${e.extra ? ' (phụ)' : ''}`),
      td(e.time || '—'),
      $('<td>').append($('<span>').addClass('legend-swatch me-2').css('background', colorFor(e.color)), $('<span>').text(e.course)),
      td(e.rooms.join(', ')),
      td(e.students, 'text-end'),
    );
    if (e.extra) $tr.addClass('table-warning');
    $tbody.append($tr);
  }
}

/**
 * Danh sách cảnh báo của buildSchedule.
 * @param {JQuery} $el
 * @param {string[]} warnings
 */
export function renderWarnings($el, warnings) {
  $el.empty();
  if (warnings.length === 0) return;
  const $ul = $('<ul>').addClass('mb-0');
  for (const w of warnings) $ul.append($('<li>').text(w));
  $el.append($('<div>').addClass('alert alert-warning').append($('<strong>').text('Cảnh báo'), $ul));
}

/**
 * Bảng so sánh hai thuật toán và hai cận.
 * @param {JQuery} $el
 * @param {ReturnType<typeof import('../core/compare.js').compareAlgorithms>} cmp
 * @param {number} repeat
 */
export function renderComparison($el, cmp, repeat) {
  const $t = $('<table>').addClass('table table-sm table-bordered align-middle mb-2');
  $t.append($('<thead>').addClass('table-light').append($('<tr>').append(
    $('<th>').text('Thuật toán'), $('<th>').addClass('text-end').text('Số màu (số ca)'),
    $('<th>').addClass('text-end').text(`Thời gian TB (ms, ${repeat} lần)`),
    $('<th>').addClass('text-end').text('Lệch so với cận dưới'), $('<th>').text('Hợp lệ'),
  )));
  const $tb = $('<tbody>');
  for (const r of cmp.results) {
    $tb.append($('<tr>').append(
      td(r.name), td(r.colorCount, 'text-end'), td(fmtMs(r.timeMs), 'text-end'),
      td(r.gapPercent === null ? '—' : fmtPct(r.gapPercent), 'text-end'),
      td(r.valid ? 'Có' : 'KHÔNG', r.valid ? 'text-success' : 'text-danger fw-bold'),
    ));
  }
  $t.append($tb);

  const [wp, ds] = cmp.results;
  const notes = [
    `Cận dưới (clique tìm tham lam): ${cmp.lowerBound} ca. Cận trên (Δ + 1): ${cmp.upperBound} ca.`,
    ds.colorCount === wp.colorCount
      ? 'Hai thuật toán dùng số màu bằng nhau.'
      : `DSATUR ${ds.colorCount < wp.colorCount ? 'ít hơn' : 'nhiều hơn'} Welsh-Powell ${Math.abs(wp.colorCount - ds.colorCount)} màu ` +
        `(cải thiện ${fmtPct(improvementPercent(wp.colorCount, ds.colorCount))}).`,
  ];
  const best = Math.min(wp.colorCount, ds.colorCount);
  if (best === cmp.lowerBound) notes.push(`Số màu ${best} bằng cận dưới nên chắc chắn là tối ưu (= χ(G)).`);
  const $notes = $('<ul>').addClass('small mb-0');
  for (const n of notes) $notes.append($('<li>').text(n));
  $el.empty().append($t, $notes);
}

/**
 * Bảng so sánh dạng CSV (để đưa vào báo cáo mục 4.3).
 * @param {ReturnType<typeof import('../core/compare.js').compareAlgorithms>} cmp
 * @returns {string}
 */
export function comparisonCsv(cmp) {
  const lines = ['Thuat toan,So mau,Thoi gian TB (ms),Hop le,Can duoi,Can tren'];
  for (const r of cmp.results) {
    lines.push([r.name, r.colorCount, r.timeMs.toFixed(4), r.valid, cmp.lowerBound, cmp.upperBound].join(','));
  }
  return lines.join('\r\n') + '\r\n';
}

/**
 * Bảng số môn, số sinh viên mỗi ca và độ lệch giữa các ca.
 * @param {JQuery} $el
 * @param {{date: string, slot: number, courses: number, students: number}[]} slots
 * @param {{days: number, periods: number}} info
 */
export function renderSlotBalance($el, slots, info) {
  const counts = slots.map((s) => s.students);
  const max = Math.max(...counts);
  const min = Math.min(...counts);
  const mean = counts.reduce((a, b) => a + b, 0) / counts.length;
  const $p = $('<p>').addClass('small mb-2').text(
    `${info.periods} ca trong ${info.days} ngày. Số lượt thi mỗi ca: ít nhất ${min}, nhiều nhất ${max}, trung bình ${mean.toFixed(1).replace('.', ',')}.`,
  );
  const $t = $('<table>').addClass('table table-sm mb-0');
  $t.append($('<thead>').addClass('table-light').append($('<tr>').append(
    $('<th>').text('Ngày'), $('<th>').text('Ca'), $('<th>').addClass('text-end').text('Số môn'),
    $('<th>').addClass('text-end').text('Lượt thi'), $('<th>').addClass('w-50').text(''),
  )));
  const $tb = $('<tbody>');
  for (const s of slots) {
    const pct = max > 0 ? (s.students / max) * 100 : 0;
    $tb.append($('<tr>').append(
      td(viDate(s.date)), td(`Ca ${s.slot}`), td(s.courses, 'text-end'), td(s.students, 'text-end'),
      $('<td>').append($('<div>').addClass('bar').css('width', `${pct}%`)),
    ));
  }
  $t.append($tb);
  $el.empty().append($p, $t);
}

/**
 * Kết quả tra cứu lịch của một sinh viên.
 * @param {JQuery} $el
 * @param {string} studentId
 * @param {import('../core/scheduler.js').ScheduleEntry[]} rows
 */
export function renderLookup($el, studentId, rows) {
  const $t = $('<table>').addClass('table table-sm table-bordered mb-0');
  $t.append($('<thead>').addClass('table-light').append($('<tr>').append(
    $('<th>').text('Môn'), $('<th>').text('Ngày'), $('<th>').text('Ca'), $('<th>').text('Giờ'), $('<th>').text('Phòng'),
  )));
  const $tb = $('<tbody>');
  for (const e of rows) {
    $tb.append($('<tr>').append(td(e.course), td(viDate(e.date)), td(`Ca ${e.slot}`), td(e.time || '—'), td(e.rooms.join(', '))));
  }
  $t.append($tb);
  $el.empty().append($('<p>').addClass('mb-2').text(`Sinh viên ${studentId.trim().toUpperCase()} có ${rows.length} môn thi:`), $t);
}

/**
 * Tải một Blob về máy bằng thẻ <a download>.
 * @param {Blob} blob
 * @param {string} filename
 */
export function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
