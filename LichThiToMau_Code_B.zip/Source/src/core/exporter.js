/**
 * exporter.js — Xuất lịch thi ra Excel (.xlsx) hoặc CSV (người D).
 * Hàm trả về Blob; giao diện (E) gắn vào nút tải xuống.
 *
 * File trong core/: không dùng document, window. Blob có sẵn trong trình duyệt và Node.js 18+.
 */
import * as XLSX from 'xlsx';

const HEADER = ['Mã môn', 'Ngày thi', 'Ca', 'Giờ bắt đầu', 'Phòng', 'Số sinh viên'];

/**
 * Chuyển lịch thành bảng hai chiều (dòng đầu là tiêu đề). Nhiều phòng ghép bằng dấu phẩy.
 * @param {{course: string, date: string, slot: number, time?: string, rooms: string[], students?: number}[]} schedule
 * @returns {(string|number)[][]}
 */
export function scheduleToRows(schedule) {
  return [
    HEADER,
    ...schedule.map((e) => [e.course, e.date, e.slot, e.time ?? '', e.rooms.join(', '), e.students ?? '']),
  ];
}

/**
 * Bọc một ô CSV trong nháy kép nếu có dấu phẩy, nháy kép hoặc xuống dòng.
 * @param {unknown} value
 * @returns {string}
 */
function csvCell(value) {
  const s = String(value ?? '');
  return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

/**
 * Tạo nội dung CSV (UTF-8 có BOM để Excel hiển thị đúng tiếng Việt).
 * @param {Parameters<typeof scheduleToRows>[0]} schedule
 * @returns {string}
 */
export function scheduleToCsv(schedule) {
  return '﻿' + scheduleToRows(schedule).map((row) => row.map(csvCell).join(',')).join('\r\n') + '\r\n';
}

/**
 * Xuất lịch thi.
 * @param {Parameters<typeof scheduleToRows>[0]} schedule
 * @param {'xlsx' | 'csv'} format
 * @returns {Promise<Blob>}
 */
export async function exportSchedule(schedule, format) {
  if (format === 'csv') {
    return new Blob([scheduleToCsv(schedule)], { type: 'text/csv;charset=utf-8' });
  }
  if (format === 'xlsx') {
    const sheet = XLSX.utils.aoa_to_sheet(scheduleToRows(schedule));
    sheet['!cols'] = [{ wch: 12 }, { wch: 12 }, { wch: 5 }, { wch: 12 }, { wch: 24 }, { wch: 13 }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, sheet, 'LichThi');
    const data = XLSX.write(wb, { type: 'array', bookType: 'xlsx' });
    return new Blob([data], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    });
  }
  throw new Error(`Định dạng xuất "${format}" không được hỗ trợ (chỉ 'xlsx' hoặc 'csv').`);
}
