/**
 * validator.js — Kiểm tra tính hợp lệ của phép tô màu, lịch thi và phòng thi (người B).
 * Cả nhóm dùng các hàm này để "chấm" kết quả của mọi thuật toán.
 *
 * File thuộc core/: không dùng document, window.
 */
import { compareIds } from './graphBuilder.js';

/** @typedef {Map<string, Set<string>>} Graph */
/** @typedef {{course: string, date: string, slot: number, rooms: string[], students?: number}} ScheduleEntry */

/**
 * Kiểm tra một phép tô màu có hợp lệ không: mọi môn có màu và hai đầu mỗi cạnh khác màu.
 * Mỗi cạnh chỉ xét một lần (chỉ khi mã u < mã v). Độ phức tạp O(V + E).
 *
 * @param {Graph} graph
 * @param {Map<string, number>} colors
 * @returns {{valid: boolean, conflicts: [string, string][], uncolored: string[]}}
 *   conflicts: các cặp môn kề nhau mà cùng màu; uncolored: các môn chưa được tô
 */
export function isValidColoring(graph, colors) {
  /** @type {[string, string][]} */
  const conflicts = [];
  /** @type {string[]} */
  const uncolored = [];

  graph.forEach((neighbors, u) => {
    if (!colors.has(u)) {
      uncolored.push(u);
      return;
    }
    const cu = colors.get(u);
    neighbors.forEach((v) => {
      if (compareIds(u, v) < 0 && colors.get(v) === cu) conflicts.push([u, v]);
    });
  });

  return { valid: conflicts.length === 0 && uncolored.length === 0, conflicts, uncolored };
}

/**
 * Số màu (số ca thi) thực sự được dùng = số giá trị màu khác nhau.
 * @param {Map<string, number>} colors
 * @returns {number}
 */
export function countColors(colors) {
  return new Set(colors.values()).size;
}

/**
 * Kiểm tra lịch thi theo từng sinh viên: không ai có hai môn cùng ngày và ca,
 * và mọi môn sinh viên đăng ký đều có mặt trong lịch. Độ phức tạp O(R).
 *
 * @param {ScheduleEntry[]} schedule
 * @param {{studentId: string, courseId: string}[]} registrations
 * @returns {{valid: boolean,
 *            conflicts: {studentId: string, date: string, slot: number, courses: [string, string]}[],
 *            missing: string[]}}
 */
export function checkScheduleByStudent(schedule, registrations) {
  const entryByCourse = new Map();
  for (const e of schedule) entryByCourse.set(e.course, e);

  const conflicts = [];
  const missing = new Set();
  // Với mỗi sinh viên: "ngày|ca" → môn đầu tiên họ thi ở ca đó
  const examsOfStudent = new Map();

  for (const reg of registrations) {
    const entry = entryByCourse.get(reg.courseId);
    if (entry === undefined) {
      missing.add(reg.courseId); // đăng ký môn không có trong lịch
      continue;
    }
    let bySlot = examsOfStudent.get(reg.studentId);
    if (!bySlot) {
      bySlot = new Map();
      examsOfStudent.set(reg.studentId, bySlot);
    }
    const key = `${entry.date}|${entry.slot}`;
    const earlier = bySlot.get(key);
    if (earlier === undefined) {
      bySlot.set(key, reg.courseId);
    } else if (earlier !== reg.courseId) {
      // earlier === courseId nghĩa là đăng ký trùng một môn, không phải xung đột lịch
      conflicts.push({
        studentId: reg.studentId,
        date: entry.date,
        slot: entry.slot,
        courses: [earlier, reg.courseId],
      });
    }
  }

  return {
    valid: conflicts.length === 0 && missing.size === 0,
    conflicts,
    missing: Array.from(missing).sort(compareIds),
  };
}

/**
 * Kiểm tra phòng thi: (1) phòng phải có trong cấu hình; (2) một phòng không dùng cho hai môn
 * trong cùng ngày và ca; (3) tổng sức chứa các phòng của môn đủ cho số sinh viên của môn
 * (chỉ kiểm khi mục lịch có trường `students`).
 *
 * @param {ScheduleEntry[]} schedule
 * @param {{id: string, capacity: number}[]} rooms
 * @returns {{valid: boolean, problems: string[]}}
 */
export function checkRooms(schedule, rooms) {
  const capacityOf = new Map(rooms.map((r) => [r.id, r.capacity]));
  const courseInRoom = new Map(); // "ngày|ca|phòng" → môn đang dùng phòng đó
  const problems = [];

  for (const e of schedule) {
    let totalCapacity = 0;
    for (const room of e.rooms) {
      if (capacityOf.has(room)) {
        totalCapacity += capacityOf.get(room);
      } else {
        problems.push(`Môn ${e.course}: phòng ${room} không có trong cấu hình.`);
      }
      const key = `${e.date}|${e.slot}|${room}`;
      if (courseInRoom.has(key)) {
        problems.push(`Phòng ${room} bị xếp cho cả ${courseInRoom.get(key)} và ${e.course} (ngày ${e.date}, ca ${e.slot}).`);
      } else {
        courseInRoom.set(key, e.course);
      }
    }
    if (e.students !== undefined && totalCapacity < e.students) {
      problems.push(`Môn ${e.course}: ${e.students} sinh viên nhưng phòng chỉ chứa ${totalCapacity}.`);
    }
  }
  return { valid: problems.length === 0, problems };
}
