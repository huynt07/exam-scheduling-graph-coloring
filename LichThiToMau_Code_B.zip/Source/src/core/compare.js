/**
 * compare.js — So sánh Welsh-Powell và DSATUR, tính cận dưới và cận trên (người B).
 *
 * File thuộc core/: không dùng document, window. performance.now() có sẵn ở cả
 * trình duyệt lẫn Node.js.
 */
import { compareIds, maxDegree } from './graphBuilder.js';
import { welshPowell } from './welshPowell.js';
import { dsatur } from './dsatur.js';
import { isValidColoring, countColors } from './validator.js';

/** @typedef {Map<string, Set<string>>} Graph */

/**
 * Tìm tham lam một clique (tập môn đôi một kề nhau) lớn.
 * Với mỗi đỉnh xuất phát s: giữ danh sách ứng viên = các đỉnh kề s, sắp theo bậc giảm dần;
 * lần lượt lấy ứng viên đầu danh sách đưa vào clique rồi lọc danh sách, chỉ giữ những đỉnh
 * kề với đỉnh vừa lấy. Khi hết ứng viên thì clique đã "cực đại". Lấy clique lớn nhất qua mọi s.
 * Độ phức tạp xấp xỉ O(V · Δ · ω), ω là cỡ clique (thường nhỏ).
 *
 * @param {Graph} graph
 * @returns {string[]} các đỉnh của clique tìm được ([] nếu đồ thị rỗng)
 */
export function greedyClique(graph) {
  const higherDegreeFirst = (a, b) => graph.get(b).size - graph.get(a).size || compareIds(a, b);
  let best = [];

  for (const start of Array.from(graph.keys()).sort(higherDegreeFirst)) {
    // Clique chứa start có tối đa bậc(start) + 1 đỉnh; không vượt được best thì bỏ qua.
    if (graph.get(start).size + 1 <= best.length) continue;

    const clique = [start];
    let candidates = Array.from(graph.get(start)).sort(higherDegreeFirst);
    while (candidates.length > 0) {
      const chosen = candidates[0];
      clique.push(chosen);
      const adjacentToChosen = graph.get(chosen);
      candidates = candidates.slice(1).filter((c) => adjacentToChosen.has(c));
    }
    if (clique.length > best.length) best = clique;
  }
  return best;
}

/**
 * Cận dưới của số sắc χ(G): cỡ clique tìm được (cỡ clique ≤ χ(G) vì các đỉnh của clique
 * phải khác màu đôi một).
 * @param {Graph} graph
 * @returns {number}
 */
export function lowerBound(graph) {
  return greedyClique(graph).length;
}

/**
 * Cận trên của số sắc: Δ(G) + 1 (đồ thị rỗng trả 0).
 * @param {Graph} graph
 * @returns {number}
 */
export function upperBound(graph) {
  if (graph.size === 0) return 0;
  return maxDegree(graph) + 1;
}

/** Hai thuật toán được so sánh, theo thứ tự hiển thị. */
export const ALGORITHMS = [
  { id: 'welshPowell', name: 'Welsh-Powell', run: welshPowell },
  { id: 'dsatur', name: 'DSATUR', run: dsatur },
];

/**
 * Đo một thuật toán: chạy `repeat` lần, lấy thời gian trung bình và kết quả của lần cuối.
 * @param {(g: Graph) => Map<string, number>} run
 * @param {Graph} graph
 * @param {number} repeat
 * @returns {{colors: Map<string, number>, timeMs: number}}
 */
function measure(run, graph, repeat) {
  let totalMs = 0;
  let colors = new Map();
  for (let i = 0; i < repeat; i++) {
    const begin = performance.now();
    colors = run(graph);
    totalMs += performance.now() - begin;
  }
  return { colors, timeMs: totalMs / repeat };
}

/**
 * Chạy cả hai thuật toán trên cùng đồ thị rồi so sánh.
 *
 * @param {Graph} graph
 * @param {{repeat?: number}} [options]  repeat: số lần lặp để đo thời gian (mặc định 20)
 * @returns {{results: {id: string, name: string, colorCount: number, timeMs: number, valid: boolean,
 *                      gapPercent: number|null, colors: Map<string, number>}[],
 *            lowerBound: number, upperBound: number}}
 *   gapPercent = (số màu − cận dưới) / cận dưới × 100; null nếu cận dưới = 0 (đồ thị rỗng)
 */
export function compareAlgorithms(graph, options = {}) {
  const repeat = Math.max(1, Math.floor(options.repeat ?? 20));
  const lb = lowerBound(graph);
  const ub = upperBound(graph);

  const results = ALGORITHMS.map(({ id, name, run }) => {
    const { colors, timeMs } = measure(run, graph, repeat);
    const colorCount = countColors(colors);
    return {
      id,
      name,
      colorCount,
      timeMs,
      valid: isValidColoring(graph, colors).valid,
      gapPercent: lb === 0 ? null : ((colorCount - lb) / lb) * 100,
      colors,
    };
  });

  return { results, lowerBound: lb, upperBound: ub };
}

/**
 * Mức cải thiện của DSATUR so với Welsh-Powell, tính theo %: (k_WP − k_DS) / k_WP × 100.
 * Âm nghĩa là DSATUR dùng nhiều màu hơn. Trả 0 nếu k_WP = 0.
 * @param {number} kWP  số màu của Welsh-Powell
 * @param {number} kDS  số màu của DSATUR
 * @returns {number}
 */
export function improvementPercent(kWP, kDS) {
  if (kWP <= 0) return 0;
  return ((kWP - kDS) / kWP) * 100;
}
