/**
 * scheduler.js — Chuyển kết quả tô màu thành lịch thi có ngày, ca, phòng (người D).
 *
 * Ý tưởng: mỗi màu là một ca. Các ca được đánh số liên tiếp p = 0, 1, 2, ...;
 * ca thứ p rơi vào ngày thi thứ ⌊p / số ca mỗi ngày⌋, ca (p mod số ca mỗi ngày) + 1.
 * Nếu một ca không đủ phòng, các môn chưa có phòng được chuyển sang một ca phụ chèn
 * ngay sau ca đó; các ca sau tự đẩy lùi một bậc vì p tăng thêm 1.
 *
 * File trong core/: không dùng document, window.
 */
import { DataError } from './dataLoader.js';
import { compareIds } from './graphBuilder.js';
import { validateConfig, examDates, orderColorsByDay, countDailyOverload } from './constraints.js';

/**
 * @typedef {Object} ScheduleEntry
 * @property {string} course     Mã môn
 * @property {string} date       Ngày thi YYYY-MM-DD
 * @property {number} slot       Ca trong ngày, đánh số từ 1
 * @property {string} time       Giờ bắt đầu ca (rỗng nếu chưa khai báo)
 * @property {string[]} rooms    Các phòng thi của môn
 * @property {number} students   Số sinh viên dự thi
 * @property {number} color      Màu (kết quả tô) của môn
 * @property {number} period     Số thứ tự ca toàn kỳ thi, từ 0
 * @property {boolean} extra     true nếu môn được chuyển sang ca phụ
 */

/**
 * Phân phòng cho một môn từ các phòng còn trống trong ca.
 * Ưu tiên một phòng nhỏ nhất đủ chứa; nếu không có thì lấy các phòng lớn nhất đến khi đủ.
 * @param {number} need  số sinh viên
 * @param {{id: string, capacity: number}[]} free  phòng còn trống, sắp sức chứa giảm dần (bị sửa)
 * @returns {string[] | null}  danh sách phòng, hoặc null nếu không đủ chỗ
 */
function allocateRooms(need, free) {
  // 1) Phòng nhỏ nhất đủ chứa (free sắp giảm dần nên duyệt ngược từ cuối).
  for (let i = free.length - 1; i >= 0; i--) {
    if (free[i].capacity >= need) return [free.splice(i, 1)[0].id];
  }
  // 2) Ghép nhiều phòng lớn nhất.
  const total = free.reduce((s, r) => s + r.capacity, 0);
  if (total < need) return null;
  const chosen = [];
  let got = 0;
  while (got < need) {
    const r = free.shift();
    chosen.push(r.id);
    got += r.capacity;
  }
  return chosen;
}

/**
 * Xếp lịch thi từ kết quả tô màu.
 *
 * @param {Map<string, number>} colors  mã môn → màu
 * @param {{studentId: string, courseId: string}[]} registrations
 * @param {import('./constraints.js').ExamConfig} config
 * @returns {{schedule: ScheduleEntry[], warnings: string[], periods: number, days: number,
 *            colorOrder: number[], overload: {students: number}}}
 * @throws {DataError} khi cấu hình sai hoặc một môn đông hơn tổng sức chứa mọi phòng
 */
export function buildSchedule(colors, registrations, config) {
  const cfg = validateConfig(config);
  const warnings = [];

  // Số sinh viên mỗi môn.
  const studentCount = new Map();
  for (const { courseId } of registrations) studentCount.set(courseId, (studentCount.get(courseId) ?? 0) + 1);

  // Kiểm tra môn quá đông so với tổng sức chứa.
  const totalCapacity = cfg.rooms.reduce((s, r) => s + r.capacity, 0);
  const tooBig = [...colors.keys()].filter((c) => (studentCount.get(c) ?? 0) > totalCapacity);
  if (tooBig.length > 0) {
    throw new DataError(
      `Tổng sức chứa mọi phòng là ${totalCapacity} chỗ, không đủ cho môn: ` +
        tooBig.map((c) => `${c} (${studentCount.get(c)} SV)`).join(', ') + '. Hãy thêm phòng.',
    );
  }

  // Gom môn theo màu; trong mỗi màu xếp môn đông trước để phân phòng tốt hơn.
  const byColor = new Map();
  for (const [course, color] of colors) {
    if (!byColor.has(color)) byColor.set(color, []);
    byColor.get(color).push(course);
  }
  for (const list of byColor.values()) {
    list.sort((a, b) => (studentCount.get(b) ?? 0) - (studentCount.get(a) ?? 0) || compareIds(a, b));
  }

  const colorOrder = orderColorsByDay(colors, registrations, cfg.slotsPerDay, cfg.maxExamsPerDay);
  const roomsDesc = [...cfg.rooms].sort((a, b) => b.capacity - a.capacity || compareIds(a.id, b.id));

  // Bước 1: gán mỗi môn vào một ca p (có thể là ca phụ) và phòng.
  /** @type {{course: string, color: number, period: number, rooms: string[], extra: boolean}[]} */
  const placed = [];
  let period = 0;
  for (const color of colorOrder) {
    let pending = byColor.get(color);
    let extra = false;
    while (pending.length > 0) {
      const free = roomsDesc.map((r) => ({ ...r }));
      const left = [];
      for (const course of pending) {
        const rooms = allocateRooms(studentCount.get(course) ?? 0, free);
        if (rooms) placed.push({ course, color, period, rooms, extra });
        else left.push(course);
      }
      period++;
      if (left.length > 0) {
        warnings.push(
          `Không đủ phòng cho màu ${color}: chuyển ${left.join(', ')} sang ca phụ ngay sau ca đó; các ca sau lùi một bậc.`,
        );
      }
      pending = left;
      extra = true;
    }
  }

  // Bước 2: đổi số thứ tự ca p thành ngày và ca trong ngày.
  const days = Math.ceil(period / cfg.slotsPerDay);
  const dates = examDates(cfg, days);
  const schedule = placed.map((p) => {
    const slotIndex = p.period % cfg.slotsPerDay;
    return {
      course: p.course,
      date: dates[Math.floor(p.period / cfg.slotsPerDay)],
      slot: slotIndex + 1,
      time: cfg.slotTimes[slotIndex] ?? '',
      rooms: p.rooms,
      students: studentCount.get(p.course) ?? 0,
      color: p.color,
      period: p.period,
      extra: p.extra,
    };
  });
  schedule.sort((a, b) => a.period - b.period || compareIds(a.course, b.course));

  // Ghi rõ ca phụ nằm ở ngày, ca nào.
  for (const e of schedule) {
    if (e.extra) warnings.push(`Môn ${e.course} (${e.students} SV) thi ở ca phụ: ngày ${e.date}, ca ${e.slot}.`);
  }

  const overload = countDailyOverload(schedule, registrations, cfg.maxExamsPerDay);
  if (overload.students > 0) {
    warnings.push(
      `${overload.students} sinh viên phải thi quá ${cfg.maxExamsPerDay} môn trong một ngày ` +
        '(đây là ràng buộc mềm; có thể tăng số ngày bằng cách giảm số ca mỗi ngày).',
    );
  }

  return { schedule, warnings, periods: period, days, colorOrder, overload };
}

/**
 * Số môn trong từng ca (theo thứ tự ca), dùng để xem mức cân bằng giữa các ca.
 * @param {ScheduleEntry[]} schedule
 * @returns {{date: string, slot: number, courses: number, students: number}[]}
 */
export function slotSummary(schedule) {
  const map = new Map();
  for (const e of schedule) {
    if (!map.has(e.period)) map.set(e.period, { date: e.date, slot: e.slot, courses: 0, students: 0 });
    const s = map.get(e.period);
    s.courses++;
    s.students += e.students;
  }
  return [...map.entries()].sort((a, b) => a[0] - b[0]).map(([, v]) => v);
}
