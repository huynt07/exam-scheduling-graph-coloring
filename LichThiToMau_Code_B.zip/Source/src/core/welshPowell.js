/**
 * welshPowell.js — Thuật toán tô màu đồ thị Welsh-Powell (người B).
 *
 * Ý tưởng: môn có nhiều môn xung đột (bậc cao) bị ràng buộc nhiều nhất nên được xét trước.
 * Mỗi màu (= một ca thi) được "lấp đầy" bằng các môn không kề nhau, hết lượt mới sang màu mới.
 *
 * File thuộc core/: không dùng document, window để kiểm thử độc lập bằng Node.js/Vitest.
 */
import { compareIds } from './graphBuilder.js';

/** @typedef {Map<string, Set<string>>} Graph  Mã môn → tập môn kề */
/** @typedef {{course: string, color: number}} ColorStep */

/**
 * Sắp các đỉnh theo bậc giảm dần; hai đỉnh bằng bậc thì mã môn nhỏ hơn đứng trước
 * (quy tắc xác định kết quả của cả nhóm, để cùng dữ liệu luôn cho cùng kết quả).
 *
 * @param {Graph} graph
 * @returns {string[]} danh sách mã môn đã sắp
 */
export function welshPowellOrder(graph) {
  const list = Array.from(graph.keys());
  list.sort((x, y) => {
    const diff = graph.get(y).size - graph.get(x).size; // bậc của y trừ bậc của x → bậc lớn lên trước
    return diff || compareIds(x, y); // diff = 0 thì so mã môn
  });
  return list;
}

/**
 * Tô màu đồ thị bằng Welsh-Powell.
 *
 * Mỗi lượt tô một màu: duyệt danh sách (đã sắp theo bậc giảm dần) những đỉnh chưa tô;
 * đỉnh nào chưa bị "chặn" thì nhận màu hiện tại, đồng thời chặn mọi đỉnh kề của nó
 * trong phần còn lại của lượt. Tập `blocked` giúp kiểm tra "có kề đỉnh cùng màu không"
 * trong O(1) thay vì quét lại các đỉnh kề.
 *
 * Độ phức tạp: sắp xếp O(V log V); mỗi lượt O(V + E); có tối đa Δ + 1 lượt
 * ⇒ O(V log V + (Δ + 1)(V + E)). Bộ nhớ O(V + E).
 *
 * @param {Graph} graph  Đồ thị xung đột
 * @param {ColorStep[] | null} [steps]  Nếu là mảng, mỗi lần tô đẩy thêm {course, color}
 * @returns {Map<string, number>} mã môn → số màu (từ 0)
 */
export function welshPowell(graph, steps = null) {
  /** @type {Map<string, number>} */
  const colorOf = new Map();
  let remaining = welshPowellOrder(graph); // các đỉnh chưa tô, giữ nguyên thứ tự bậc giảm dần
  let color = 0;

  while (remaining.length > 0) {
    const blocked = new Set(); // các đỉnh kề với một đỉnh đã nhận `color` trong lượt này
    const left = []; // các đỉnh chưa tô sau lượt này

    for (const v of remaining) {
      if (blocked.has(v)) {
        left.push(v);
        continue;
      }
      colorOf.set(v, color);
      if (steps) steps.push({ course: v, color });
      for (const u of graph.get(v)) blocked.add(u);
    }

    remaining = left;
    color += 1; // sang màu mới
  }
  return colorOf;
}
