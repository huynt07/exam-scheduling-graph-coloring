/**
 * constraints.js — Cấu hình lịch thi và ràng buộc mở rộng (người D).
 *
 * Gồm: cấu hình mặc định, kiểm tra/chuẩn hóa cấu hình, lưu và đọc cấu hình bằng JSON,
 * tính ngày thi bỏ qua ngày nghỉ, và sắp thứ tự màu vào ngày để giảm số sinh viên
 * thi quá nhiều môn trong một ngày.
 *
 * File trong core/: không dùng document, window.
 */
import { DataError } from './dataLoader.js';

/**
 * @typedef {Object} ExamConfig
 * @property {string} startDate          Ngày thi đầu tiên, dạng YYYY-MM-DD
 * @property {number} slotsPerDay        Số ca mỗi ngày
 * @property {string[]} slotTimes        Giờ bắt đầu từng ca, ví dụ ["07:30", "09:30", "13:30"]
 * @property {{id: string, capacity: number}[]} rooms  Danh sách phòng và sức chứa
 * @property {string[]} holidays         Các ngày nghỉ, dạng YYYY-MM-DD
 * @property {boolean} skipSundays       Không thi vào Chủ nhật
 * @property {number | null} maxExamsPerDay  Số môn tối đa một sinh viên thi trong một ngày (null: không xét)
 */

/** @returns {ExamConfig} cấu hình mặc định, người dùng sửa trên giao diện */
export function defaultConfig() {
  return {
    startDate: '',
    slotsPerDay: 3,
    slotTimes: ['07:30', '09:30', '13:30'],
    rooms: [],
    holidays: [],
    skipSundays: true,
    maxExamsPerDay: 2,
  };
}

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

/**
 * Kiểm tra chuỗi ngày YYYY-MM-DD có thật (không nhận 2026-02-30).
 * @param {string} s
 * @returns {boolean}
 */
export function isValidDate(s) {
  if (typeof s !== 'string' || !DATE_RE.test(s)) return false;
  const d = new Date(`${s}T00:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s;
}

/**
 * Kiểm tra và chuẩn hóa cấu hình. Ném DataError liệt kê mọi lỗi.
 * @param {Partial<ExamConfig>} input
 * @returns {ExamConfig}
 */
export function validateConfig(input) {
  const c = { ...defaultConfig(), ...(input || {}) };
  const errors = [];

  if (!isValidDate(c.startDate)) errors.push('Ngày bắt đầu phải có dạng YYYY-MM-DD và là ngày có thật.');

  const slots = Number(c.slotsPerDay);
  if (!Number.isInteger(slots) || slots < 1 || slots > 10) errors.push('Số ca mỗi ngày phải là số nguyên từ 1 đến 10.');

  const slotTimes = (c.slotTimes || []).map((t) => String(t).trim()).filter(Boolean);

  const rooms = [];
  const roomIds = new Set();
  for (const r of c.rooms || []) {
    const id = String(r.id ?? '').trim().toUpperCase();
    const cap = Number(r.capacity);
    if (id === '') {
      errors.push('Có phòng chưa nhập mã.');
    } else if (roomIds.has(id)) {
      errors.push(`Phòng ${id} bị khai báo hai lần.`);
    } else if (!Number.isInteger(cap) || cap < 1) {
      errors.push(`Sức chứa phòng ${id} phải là số nguyên dương.`);
    } else {
      roomIds.add(id);
      rooms.push({ id, capacity: cap });
    }
  }
  if (rooms.length === 0) errors.push('Cần khai báo ít nhất một phòng thi.');

  const holidays = [];
  for (const h of c.holidays || []) {
    const s = String(h).trim();
    if (s === '') continue;
    if (!isValidDate(s)) errors.push(`Ngày nghỉ "${s}" không hợp lệ (dạng YYYY-MM-DD).`);
    else holidays.push(s);
  }

  let maxExamsPerDay = c.maxExamsPerDay;
  if (maxExamsPerDay === '' || maxExamsPerDay === null || maxExamsPerDay === undefined) {
    maxExamsPerDay = null;
  } else {
    maxExamsPerDay = Number(maxExamsPerDay);
    if (!Number.isInteger(maxExamsPerDay) || maxExamsPerDay < 1) {
      errors.push('Số môn tối đa mỗi ngày phải là số nguyên dương hoặc để trống.');
    }
  }

  if (errors.length > 0) throw new DataError(`Cấu hình lịch thi có lỗi:\n${errors.join('\n')}`);
  return {
    startDate: c.startDate,
    slotsPerDay: slots,
    slotTimes,
    rooms,
    holidays: [...new Set(holidays)].sort(),
    skipSundays: Boolean(c.skipSundays),
    maxExamsPerDay,
  };
}

/**
 * Lưu cấu hình thành chuỗi JSON (để tải về và mở lại lần sau).
 * @param {ExamConfig} config
 * @returns {string}
 */
export function configToJson(config) {
  return JSON.stringify(config, null, 2);
}

/**
 * Đọc cấu hình từ chuỗi JSON rồi kiểm tra.
 * @param {string} text
 * @returns {ExamConfig}
 */
export function configFromJson(text) {
  let obj;
  try {
    obj = JSON.parse(text);
  } catch {
    throw new DataError('File cấu hình không phải JSON hợp lệ.');
  }
  return validateConfig(obj);
}

/**
 * Danh sách `count` ngày thi liên tiếp kể từ startDate, bỏ ngày nghỉ và Chủ nhật (nếu chọn).
 * Dùng giờ UTC để không bị lệch ngày theo múi giờ của máy.
 * @param {ExamConfig} config
 * @param {number} count
 * @returns {string[]}
 */
export function examDates(config, count) {
  const holidays = new Set(config.holidays);
  const dates = [];
  const d = new Date(`${config.startDate}T00:00:00Z`);
  while (dates.length < count) {
    const s = d.toISOString().slice(0, 10);
    const isSunday = d.getUTCDay() === 0;
    if (!holidays.has(s) && !(config.skipSundays && isSunday)) dates.push(s);
    d.setUTCDate(d.getUTCDate() + 1);
  }
  return dates;
}

/**
 * Sắp thứ tự các màu vào ngày để giảm số lần sinh viên thi quá maxPerDay môn/ngày.
 * Tham lam theo từng ngày: lần lượt chọn màu còn lại làm tăng vi phạm ít nhất
 * (hòa thì màu có số nhỏ hơn), đủ slotsPerDay màu thì sang ngày mới.
 * Không thay đổi phép tô màu nên lịch vẫn không trùng ca.
 *
 * @param {Map<string, number>} colors  mã môn → màu
 * @param {{studentId: string, courseId: string}[]} registrations
 * @param {number} slotsPerDay
 * @param {number | null} maxPerDay  null: giữ thứ tự 0, 1, 2, ...
 * @returns {number[]} thứ tự các màu
 */
export function orderColorsByDay(colors, registrations, slotsPerDay, maxPerDay) {
  const colorList = [...new Set(colors.values())].sort((a, b) => a - b);
  if (!maxPerDay) return colorList;

  // Màu → danh sách sinh viên có môn mang màu đó (mỗi SV tối đa một môn mỗi màu).
  const studentsByColor = new Map(colorList.map((c) => [c, []]));
  for (const { studentId, courseId } of registrations) {
    if (colors.has(courseId)) studentsByColor.get(colors.get(courseId)).push(studentId);
  }

  const remaining = new Set(colorList);
  const order = [];
  let dayCount = new Map(); // SV → số môn đã xếp trong ngày đang xét
  while (remaining.size > 0) {
    if (order.length % slotsPerDay === 0) dayCount = new Map();
    let best = null;
    let bestCost = Infinity;
    for (const c of remaining) {
      let cost = 0;
      for (const s of studentsByColor.get(c)) {
        if ((dayCount.get(s) ?? 0) >= maxPerDay) cost++;
      }
      if (cost < bestCost) {
        best = c;
        bestCost = cost;
      }
    }
    order.push(best);
    remaining.delete(best);
    for (const s of studentsByColor.get(best)) dayCount.set(s, (dayCount.get(s) ?? 0) + 1);
  }
  return order;
}

/**
 * Đếm số sinh viên thi quá maxPerDay môn trong ít nhất một ngày.
 * @param {{course: string, date: string}[]} schedule
 * @param {{studentId: string, courseId: string}[]} registrations
 * @param {number | null} maxPerDay
 * @returns {{students: number, examples: {studentId: string, date: string, count: number}[]}}
 */
export function countDailyOverload(schedule, registrations, maxPerDay) {
  if (!maxPerDay) return { students: 0, examples: [] };
  const dateOf = new Map(schedule.map((e) => [e.course, e.date]));
  const perDay = new Map(); // "SV|ngày" → số môn
  for (const { studentId, courseId } of registrations) {
    const date = dateOf.get(courseId);
    if (!date) continue;
    const key = `${studentId}|${date}`;
    perDay.set(key, (perDay.get(key) ?? 0) + 1);
  }
  const over = new Set();
  const examples = [];
  for (const [key, count] of perDay) {
    if (count > maxPerDay) {
      const [studentId, date] = key.split('|');
      over.add(studentId);
      if (examples.length < 5) examples.push({ studentId, date, count });
    }
  }
  return { students: over.size, examples };
}
