import { describe, it, expect } from 'vitest';
import { readFileSync } from 'node:fs';
import { parseRegistrationsCsv } from '../src/core/dataLoader.js';
import { buildGraph, maxDegree } from '../src/core/graphBuilder.js';
import {
  compareAlgorithms,
  lowerBound,
  upperBound,
  greedyClique,
  improvementPercent,
} from '../src/core/compare.js';
import { generateRegistrations } from './helpers/randomData.js';

const smallGraph = () =>
  buildGraph(parseRegistrationsCsv(readFileSync(new URL('./fixtures/small.csv', import.meta.url), 'utf8')));

function makeGraph(vertices, edges) {
  const g = new Map(vertices.map((v) => [v, new Set()]));
  for (const [u, v] of edges) {
    g.get(u).add(v);
    g.get(v).add(u);
  }
  return g;
}

describe('cận dưới và cận trên', () => {
  it('bộ nhỏ: có K4 {CTDL, GT, LTDT, TRR} nên cận dưới 4; Δ = 4 nên cận trên 5', () => {
    const g = smallGraph();
    expect(lowerBound(g)).toBe(4);
    expect(upperBound(g)).toBe(5);
    expect(greedyClique(g).sort()).toEqual(['CTDL', 'GT', 'LTDT', 'TRR']);
  });

  it('clique tìm được đúng là clique: mọi cặp đỉnh đều kề nhau', () => {
    for (const seed of [11, 12, 13]) {
      const g = buildGraph(generateRegistrations(seed, { students: 300, courses: 40, coursesPerStudent: [2, 5] }));
      const clique = greedyClique(g);
      for (let i = 0; i < clique.length; i++)
        for (let j = i + 1; j < clique.length; j++) expect(g.get(clique[i]).has(clique[j])).toBe(true);
    }
  });

  it('đồ thị rỗng: cả hai cận bằng 0', () => {
    expect(lowerBound(new Map())).toBe(0);
    expect(upperBound(new Map())).toBe(0);
  });

  it('đồ thị không cạnh: cận dưới 1, cận trên 1', () => {
    const g = makeGraph(['A', 'B', 'C'], []);
    expect(lowerBound(g)).toBe(1);
    expect(upperBound(g)).toBe(1);
  });
});

describe('compareAlgorithms', () => {
  it('trả hai thuật toán, mọi kết quả hợp lệ và nằm giữa hai cận', () => {
    for (const seed of [21, 22, 23, 24]) {
      const g = buildGraph(generateRegistrations(seed, { students: 500, courses: 60, coursesPerStudent: [3, 6] }));
      const { results, lowerBound: lb, upperBound: ub } = compareAlgorithms(g, { repeat: 2 });
      expect(results.map((r) => r.name)).toEqual(['Welsh-Powell', 'DSATUR']);
      expect(ub).toBe(maxDegree(g) + 1);
      for (const r of results) {
        expect(r.valid).toBe(true);
        expect(r.colorCount).toBeGreaterThanOrEqual(lb);
        expect(r.colorCount).toBeLessThanOrEqual(ub);
        expect(r.timeMs).toBeGreaterThanOrEqual(0);
      }
    }
  });

  it('bộ nhỏ: cả hai dùng 4 màu = cận dưới, độ lệch 0%', () => {
    const { results } = compareAlgorithms(smallGraph(), { repeat: 1 });
    for (const r of results) {
      expect(r.colorCount).toBe(4);
      expect(r.gapPercent).toBe(0);
    }
  });

  it('cùng seed cho cùng bảng kết quả (trừ thời gian)', () => {
    const table = () => {
      const g = buildGraph(generateRegistrations(77, { students: 300, courses: 40, coursesPerStudent: 4 }));
      const c = compareAlgorithms(g, { repeat: 1 });
      return {
        lb: c.lowerBound,
        ub: c.upperBound,
        rows: c.results.map((r) => [r.name, r.colorCount, r.valid, [...r.colors]]),
      };
    };
    expect(table()).toEqual(table());
  });

  it('đồ thị rỗng: không lỗi, độ lệch là null', () => {
    const { results, lowerBound: lb } = compareAlgorithms(new Map(), { repeat: 1 });
    expect(lb).toBe(0);
    for (const r of results) {
      expect(r.colorCount).toBe(0);
      expect(r.gapPercent).toBeNull();
    }
  });

  it('repeat không hợp lệ được đưa về ít nhất 1 lần', () => {
    expect(() => compareAlgorithms(smallGraph(), { repeat: 0 })).not.toThrow();
  });
});

describe('improvementPercent', () => {
  it('tính (kWP − kDS) / kWP × 100', () => {
    expect(improvementPercent(10, 8)).toBeCloseTo(20);
    expect(improvementPercent(5, 5)).toBe(0);
    expect(improvementPercent(4, 5)).toBeCloseTo(-25);
    expect(improvementPercent(0, 0)).toBe(0);
  });
});
