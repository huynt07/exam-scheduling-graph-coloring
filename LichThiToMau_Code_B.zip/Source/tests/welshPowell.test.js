import { describe, it, expect } from 'vitest';
import { readFileSync } from 'node:fs';
import { parseRegistrationsCsv } from '../src/core/dataLoader.js';
import { buildGraph, maxDegree } from '../src/core/graphBuilder.js';
import { welshPowell, welshPowellOrder } from '../src/core/welshPowell.js';
import { isValidColoring, countColors } from '../src/core/validator.js';
import { generateRegistrations } from './helpers/randomData.js';

const smallGraph = () =>
  buildGraph(parseRegistrationsCsv(readFileSync(new URL('./fixtures/small.csv', import.meta.url), 'utf8')));

/** Dựng đồ thị từ danh sách đỉnh và danh sách cạnh. */
function makeGraph(vertices, edges) {
  const g = new Map();
  for (const v of vertices) g.set(v, new Set());
  for (const [u, v] of edges) {
    g.get(u).add(v);
    g.get(v).add(u);
  }
  return g;
}

/** Đồ thị đầy đủ K_n. */
function completeGraph(n) {
  const vs = Array.from({ length: n }, (_, i) => `M${i}`);
  const es = [];
  for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) es.push([vs[i], vs[j]]);
  return makeGraph(vs, es);
}

/** Đồ thị "vương miện": A_i kề B_j khi i ≠ j (hai phía nên 2 màu là đủ). */
function crownGraph(n) {
  const vs = [];
  const es = [];
  for (let i = 1; i <= n; i++) vs.push(`A${i}`, `B${i}`);
  for (let i = 1; i <= n; i++) for (let j = 1; j <= n; j++) if (i !== j) es.push([`A${i}`, `B${j}`]);
  return makeGraph(vs, es);
}

/** Tô tham lam theo một thứ tự đỉnh cho trước: mỗi đỉnh nhận màu nhỏ nhất chưa có ở đỉnh kề. */
function greedyInOrder(graph, order) {
  const colors = new Map();
  for (const v of order) {
    const used = new Set();
    for (const u of graph.get(v)) if (colors.has(u)) used.add(colors.get(u));
    let c = 0;
    while (used.has(c)) c++;
    colors.set(v, c);
  }
  return colors;
}

describe('Welsh-Powell: bộ nhỏ vẽ tay', () => {
  it('thứ tự xét: bậc giảm dần, bằng bậc thì mã tăng dần', () => {
    expect(welshPowellOrder(smallGraph())).toEqual(['GT', 'LTDT', 'TRR', 'CTDL', 'MMT', 'CSDL', 'XSTK', 'TA']);
  });

  it('khớp từng ca với kết quả tô tay', () => {
    const colors = welshPowell(smallGraph());
    const byColor = {};
    for (const [course, c] of colors) (byColor[c] ??= []).push(course);
    for (const c in byColor) byColor[c].sort();
    expect(byColor).toEqual({
      0: ['GT', 'MMT', 'TA'],
      1: ['CSDL', 'LTDT'],
      2: ['TRR', 'XSTK'],
      3: ['CTDL'],
    });
    expect(isValidColoring(smallGraph(), colors).valid).toBe(true);
  });

  it('steps ghi đúng thứ tự tô, mỗi môn một lần', () => {
    const steps = [];
    const colors = welshPowell(smallGraph(), steps);
    expect(steps).toHaveLength(8);
    expect(steps[0]).toEqual({ course: 'GT', color: 0 });
    expect(steps[steps.length - 1]).toEqual({ course: 'CTDL', color: 3 });
    for (const { course, color } of steps) expect(colors.get(course)).toBe(color);
    // màu trong steps không giảm: lượt màu k xong mới sang màu k + 1
    for (let i = 1; i < steps.length; i++) expect(steps[i].color).toBeGreaterThanOrEqual(steps[i - 1].color);
  });
});

describe('Welsh-Powell: trường hợp đặc biệt', () => {
  it('K_n cần đúng n màu', () => {
    for (const n of [1, 2, 4, 7]) {
      const g = completeGraph(n);
      const colors = welshPowell(g);
      expect(countColors(colors)).toBe(n);
      expect(isValidColoring(g, colors).valid).toBe(true);
    }
  });

  it('đồ thị không có cạnh cần 1 màu; đồ thị rỗng cần 0', () => {
    expect(countColors(welshPowell(makeGraph(['X', 'Y', 'Z'], [])))).toBe(1);
    expect(welshPowell(new Map()).size).toBe(0);
  });

  it('chu trình lẻ C5 cần 3 màu', () => {
    const g = makeGraph(['a', 'b', 'c', 'd', 'e'], [['a', 'b'], ['b', 'c'], ['c', 'd'], ['d', 'e'], ['e', 'a']]);
    expect(countColors(welshPowell(g))).toBe(3);
  });

  it('cùng đầu vào cho cùng kết quả', () => {
    expect([...welshPowell(smallGraph())]).toEqual([...welshPowell(smallGraph())]);
  });
});

describe('Welsh-Powell: tính chất tổng quát', () => {
  it('hợp lệ và không vượt Δ + 1 trên dữ liệu sinh có seed', () => {
    for (const seed of [1, 2, 3, 4, 5]) {
      const g = buildGraph(generateRegistrations(seed, { students: 400, courses: 50, coursesPerStudent: [2, 6] }));
      const colors = welshPowell(g);
      expect(isValidColoring(g, colors).valid).toBe(true);
      expect(countColors(colors)).toBeLessThanOrEqual(maxDegree(g) + 1);
    }
  });

  it('thứ tự đỉnh ảnh hưởng số màu: vương miện cần n màu theo bậc, 2 màu nếu xếp cùng phía trước', () => {
    const n = 5;
    const g = crownGraph(n);
    // Mọi đỉnh bằng bậc n − 1 nên Welsh-Powell xét theo mã: A1, A2, ... rồi B1, B2, ...
    // ⇒ không xen kẽ, kết quả phụ thuộc cách đặt mã. Dùng mã xen kẽ để thấy rõ tác động của thứ tự.
    const interleaved = [];
    for (let i = 1; i <= n; i++) interleaved.push(`A${i}`, `B${i}`);
    const sideBySide = [];
    for (let i = 1; i <= n; i++) sideBySide.push(`A${i}`);
    for (let i = 1; i <= n; i++) sideBySide.push(`B${i}`);

    expect(countColors(greedyInOrder(g, interleaved))).toBe(n);
    expect(countColors(greedyInOrder(g, sideBySide))).toBe(2);
  });
});
