import { describe, it, expect } from 'vitest';
import { readFileSync } from 'node:fs';
import * as XLSX from 'xlsx';
import {
  DataError,
  normalizeHeader,
  normalizeCode,
  detectDelimiter,
  parseRegistrationsCsv,
  parseRegistrationsExcel,
  validateRegistrations,
  summarizeRegistrations,
} from '../src/core/dataLoader.js';

const fixture = (name) => readFileSync(new URL(`./fixtures/${name}`, import.meta.url), 'utf8');

/** Tạo file .xlsx trong bộ nhớ từ mảng hai chiều (giả lập file người dùng tải lên). */
function makeXlsx(aoa, sheetName = 'Sheet1') {
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(aoa), sheetName);
  return new Uint8Array(XLSX.write(wb, { type: 'array', bookType: 'xlsx' }));
}

describe('chuẩn hóa', () => {
  it('nhận tên cột tiếng Việt, không phân biệt hoa thường, bỏ khoảng trắng', () => {
    expect(normalizeHeader(' Mã SV ')).toBe('masv');
    expect(normalizeHeader('MSSV')).toBe('mssv');
    expect(normalizeHeader('Mã môn')).toBe('mamon');
    expect(normalizeHeader('StudentId')).toBe('studentid');
  });

  it('chuẩn hóa mã: cắt khoảng trắng, viết hoa, giữ số 0 đầu', () => {
    expect(normalizeCode('  it001 ')).toBe('IT001');
    expect(normalizeCode('0123')).toBe('0123');
    expect(normalizeCode(undefined)).toBe('');
  });

  it('nhận dấu phân cách , hoặc ;', () => {
    expect(detectDelimiter('studentId,courseId')).toBe(',');
    expect(detectDelimiter('MSSV;Mã môn')).toBe(';');
  });
});

describe('parseRegistrationsCsv', () => {
  it('đọc bộ nhỏ', () => {
    const regs = parseRegistrationsCsv(fixture('small.csv'));
    expect(regs).toHaveLength(19);
    expect(regs[0]).toEqual({ studentId: 'SV01', courseId: 'CTDL' });
  });

  it('đọc CSV có BOM, dấu ;, cột MSSV/Mã môn, dòng trống, mã có số 0 đầu', () => {
    const regs = parseRegistrationsCsv(fixture('vietnamese.csv'));
    expect(regs).toEqual([
      { studentId: '0123', courseId: 'IT001' },
      { studentId: '0123', courseId: 'IT002' },
      { studentId: '0456', courseId: 'IT001' },
    ]);
  });

  it('bỏ cặp nháy kép quanh ô và bỏ qua cột thừa', () => {
    const regs = parseRegistrationsCsv('hoTen,"studentId","courseId"\nAn,"007","CTDL"\n');
    expect(regs).toEqual([{ studentId: '007', courseId: 'CTDL' }]);
  });

  it('báo lỗi thiếu cột', () => {
    expect(() => parseRegistrationsCsv('studentId,tenMon\nSV01,Toan\n')).toThrow(/thiếu cột mã môn/);
  });

  it('báo lỗi ô trống kèm số dòng trong file', () => {
    const text = 'studentId,courseId\nSV01,CTDL\nSV02,\n';
    expect(() => parseRegistrationsCsv(text)).toThrow(/Dòng 3: thiếu mã môn/);
  });

  it('báo lỗi đăng ký trùng, chỉ ra cả dòng đầu tiên', () => {
    const text = 'studentId,courseId\nSV01,CTDL\nSV02,GT\nsv01 , ctdl\n';
    try {
      parseRegistrationsCsv(text);
      expect.unreachable();
    } catch (e) {
      expect(e).toBeInstanceOf(DataError);
      expect(e.message).toMatch(/Dòng 4: .*SV01.*CTDL.*dòng 2/);
      expect(e.details).toHaveLength(1);
      expect(e.details[0].line).toBe(4);
    }
  });

  it('gom nhiều lỗi vào một thông báo', () => {
    const text = 'studentId,courseId\n,CTDL\nSV02,\nSV03,GT\n';
    try {
      parseRegistrationsCsv(text);
      expect.unreachable();
    } catch (e) {
      expect(e.details.map((d) => d.line)).toEqual([2, 3]);
      expect(e.message).toMatch(/có 2 lỗi/);
    }
  });

  it('báo lỗi file rỗng hoặc chỉ có tiêu đề', () => {
    expect(() => parseRegistrationsCsv('')).toThrow(/rỗng/);
    expect(() => parseRegistrationsCsv('﻿\n\n')).toThrow(/rỗng/);
    expect(() => parseRegistrationsCsv('studentId,courseId\n')).toThrow(/Không có dòng đăng ký/);
  });
});

describe('parseRegistrationsExcel', () => {
  it('đọc sheet đầu tiên, giữ số 0 đầu của ô kiểu chuỗi', () => {
    const data = makeXlsx([
      ['Mã SV', 'Mã môn'],
      ['0123', 'IT001'],
      [123, 'IT002'], // ô kiểu số vẫn đọc thành chuỗi "123"
    ]);
    expect(parseRegistrationsExcel(data)).toEqual([
      { studentId: '0123', courseId: 'IT001' },
      { studentId: '123', courseId: 'IT002' },
    ]);
  });

  it('bỏ dòng trống và báo đúng số dòng như trong Excel', () => {
    const data = makeXlsx([['studentId', 'courseId'], ['SV01', 'CTDL'], [], ['SV02', '']]);
    expect(() => parseRegistrationsExcel(data)).toThrow(/Dòng 4: thiếu mã môn/);
  });

  it('chỉ đọc sheet đầu tiên', () => {
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([['studentId', 'courseId'], ['SV01', 'A']]), 'DauTien');
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([['studentId', 'courseId'], ['SV99', 'Z']]), 'ThuHai');
    const data = new Uint8Array(XLSX.write(wb, { type: 'array', bookType: 'xlsx' }));
    expect(parseRegistrationsExcel(data)).toEqual([{ studentId: 'SV01', courseId: 'A' }]);
  });

  it('báo lỗi sheet rỗng và file không phải Excel', () => {
    expect(() => parseRegistrationsExcel(makeXlsx([]))).toThrow(/không có dữ liệu/);
    expect(() => parseRegistrationsExcel(new Uint8Array([1, 2, 3, 4]))).toThrow(DataError);
  });
});

describe('validateRegistrations (nhập trực tiếp)', () => {
  it('chuẩn hóa và bỏ dòng trống', () => {
    const regs = validateRegistrations([
      { studentId: ' sv01', courseId: 'ctdl ' },
      { studentId: '', courseId: '' },
      { studentId: 'SV02', courseId: 'GT' },
    ]);
    expect(regs).toEqual([
      { studentId: 'SV01', courseId: 'CTDL' },
      { studentId: 'SV02', courseId: 'GT' },
    ]);
  });

  it('báo số dòng trên bảng nhập khi thiếu mã hoặc trùng', () => {
    expect(() => validateRegistrations([{ studentId: 'SV01' }])).toThrow(/Dòng 1: thiếu mã môn/);
    expect(() =>
      validateRegistrations([
        { studentId: 'SV01', courseId: 'GT' },
        { studentId: 'SV01', courseId: 'GT' },
      ]),
    ).toThrow(/Dòng 2:.*trùng với dòng 1/);
  });

  it('hai cách nhập cho cùng kết quả', () => {
    const fromCsv = parseRegistrationsCsv(fixture('small.csv'));
    const fromTable = validateRegistrations(fromCsv.map((r) => ({ ...r })));
    expect(fromTable).toEqual(fromCsv);
  });

  it('từ chối đầu vào không phải mảng hoặc toàn dòng trống', () => {
    expect(() => validateRegistrations(null)).toThrow(DataError);
    expect(() => validateRegistrations([{ studentId: '', courseId: '' }])).toThrow(/Không có dòng/);
  });
});

describe('summarizeRegistrations', () => {
  it('đếm số sinh viên, số môn, số dòng của bộ nhỏ', () => {
    const regs = parseRegistrationsCsv(fixture('small.csv'));
    expect(summarizeRegistrations(regs)).toEqual({ students: 10, courses: 8, rows: 19 });
  });
});
