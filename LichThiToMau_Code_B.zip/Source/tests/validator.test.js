import { describe, it, expect } from 'vitest';
import { readFileSync } from 'node:fs';
import { parseRegistrationsCsv } from '../src/core/dataLoader.js';
import { buildGraph } from '../src/core/graphBuilder.js';
import { welshPowell } from '../src/core/welshPowell.js';
import { isValidColoring, countColors, checkScheduleByStudent, checkRooms } from '../src/core/validator.js';

const csv = readFileSync(new URL('./fixtures/small.csv', import.meta.url), 'utf8');
const registrations = parseRegistrationsCsv(csv);
const graph = () => buildGraph(registrations);

describe('isValidColoring', () => {
  it('chấp nhận phép tô đúng', () => {
    const r = isValidColoring(graph(), welshPowell(graph()));
    expect(r).toEqual({ valid: true, conflicts: [], uncolored: [] });
  });

  it('bắt được hai môn kề nhau cùng màu', () => {
    const colors = welshPowell(graph());
    colors.set('CTDL', colors.get('GT')); // CTDL kề GT
    const r = isValidColoring(graph(), colors);
    expect(r.valid).toBe(false);
    expect(r.conflicts).toContainEqual(['CTDL', 'GT']);
  });

  it('cho cùng một màu cho tất cả → mọi cạnh đều là xung đột (11 cạnh)', () => {
    const all0 = new Map([...graph().keys()].map((c) => [c, 0]));
    const r = isValidColoring(graph(), all0);
    expect(r.conflicts).toHaveLength(11);
  });

  it('bắt được môn chưa tô màu', () => {
    const colors = welshPowell(graph());
    colors.delete('TA');
    const r = isValidColoring(graph(), colors);
    expect(r.valid).toBe(false);
    expect(r.uncolored).toEqual(['TA']);
  });

  it('mỗi cặp xung đột chỉ báo một lần', () => {
    const g = new Map([['A', new Set(['B'])], ['B', new Set(['A'])]]);
    const r = isValidColoring(g, new Map([['A', 0], ['B', 0]]));
    expect(r.conflicts).toHaveLength(1);
  });
});

describe('countColors', () => {
  it('đếm số giá trị màu khác nhau', () => {
    expect(countColors(new Map([['a', 0], ['b', 2], ['c', 2]]))).toBe(2);
    expect(countColors(new Map())).toBe(0);
  });
});

describe('checkScheduleByStudent', () => {
  // Lịch hợp lệ: mỗi màu của Welsh-Powell là một ca, 2 ca mỗi ngày
  const scheduleFromColors = (colors, slotsPerDay = 2) =>
    [...colors].map(([course, c]) => ({
      course,
      date: `2025-01-${String(10 + Math.floor(c / slotsPerDay)).padStart(2, '0')}`,
      slot: c % slotsPerDay,
      rooms: ['P1'],
    }));

  it('lịch từ phép tô hợp lệ thì không sinh viên nào trùng ca', () => {
    const r = checkScheduleByStudent(scheduleFromColors(welshPowell(graph())), registrations);
    expect(r).toEqual({ valid: true, conflicts: [], missing: [] });
  });

  it('bắt được lịch cố tình xếp trùng ca', () => {
    const schedule = scheduleFromColors(welshPowell(graph()));
    // SV01 học CTDL, GT, TRR: ép CTDL vào đúng ngày, ca của GT
    const gt = schedule.find((e) => e.course === 'GT');
    const ctdl = schedule.find((e) => e.course === 'CTDL');
    ctdl.date = gt.date;
    ctdl.slot = gt.slot;
    const r = checkScheduleByStudent(schedule, registrations);
    expect(r.valid).toBe(false);
    const ids = r.conflicts.map((c) => c.studentId);
    expect(ids).toContain('SV01'); // CTDL và GT
    expect(r.conflicts.flatMap((c) => c.courses)).toContain('CTDL');
  });

  it('báo môn sinh viên đăng ký nhưng không có trong lịch', () => {
    const schedule = scheduleFromColors(welshPowell(graph())).filter((e) => e.course !== 'TA');
    const r = checkScheduleByStudent(schedule, registrations);
    expect(r.valid).toBe(false);
    expect(r.missing).toEqual(['TA']);
  });

  it('đăng ký trùng một môn không bị tính là xung đột lịch', () => {
    const schedule = [{ course: 'M1', date: 'd1', slot: 0, rooms: ['P1'] }];
    const regs = [{ studentId: 'S', courseId: 'M1' }, { studentId: 'S', courseId: 'M1' }];
    expect(checkScheduleByStudent(schedule, regs).valid).toBe(true);
  });

  it('cùng ca nhưng khác ngày thì không xung đột', () => {
    const schedule = [
      { course: 'M1', date: 'd1', slot: 0, rooms: ['P1'] },
      { course: 'M2', date: 'd2', slot: 0, rooms: ['P1'] },
    ];
    const regs = [{ studentId: 'S', courseId: 'M1' }, { studentId: 'S', courseId: 'M2' }];
    expect(checkScheduleByStudent(schedule, regs).valid).toBe(true);
  });
});

describe('checkRooms', () => {
  const rooms = [{ id: 'P1', capacity: 40 }, { id: 'P2', capacity: 40 }];

  it('hợp lệ khi phòng đủ chỗ và không trùng', () => {
    const schedule = [
      { course: 'A', date: 'd1', slot: 0, rooms: ['P1', 'P2'], students: 70 },
      { course: 'B', date: 'd1', slot: 1, rooms: ['P1'], students: 30 },
    ];
    expect(checkRooms(schedule, rooms)).toEqual({ valid: true, problems: [] });
  });

  it('bắt phòng dùng cho hai môn cùng ca', () => {
    const schedule = [
      { course: 'A', date: 'd1', slot: 0, rooms: ['P1'] },
      { course: 'B', date: 'd1', slot: 0, rooms: ['P1'] },
    ];
    const r = checkRooms(schedule, rooms);
    expect(r.valid).toBe(false);
    expect(r.problems).toHaveLength(1);
  });

  it('bắt phòng không đủ sức chứa và phòng không tồn tại', () => {
    const r = checkRooms(
      [
        { course: 'A', date: 'd1', slot: 0, rooms: ['P1'], students: 50 },
        { course: 'B', date: 'd1', slot: 1, rooms: ['P9'] },
      ],
      rooms,
    );
    expect(r.valid).toBe(false);
    expect(r.problems).toHaveLength(2);
  });
});
