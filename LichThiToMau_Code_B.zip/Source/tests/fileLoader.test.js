import { describe, it, expect } from 'vitest';
import { readFileSync } from 'node:fs';
import * as XLSX from 'xlsx';
import { loadRegistrations } from '../src/ui/fileLoader.js';

// Node.js 22 có sẵn lớp File giống trình duyệt nên kiểm thử được fileLoader ngoài trình duyệt.
const csv = readFileSync(new URL('./fixtures/small.csv', import.meta.url));

describe('loadRegistrations', () => {
  it('đọc file .csv', async () => {
    const regs = await loadRegistrations(new File([csv], 'DangKy.CSV'));
    expect(regs).toHaveLength(19);
  });

  it('đọc file .xlsx', async () => {
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([['MSSV', 'Mã môn'], ['0123', 'IT001']]), 'S');
    const bytes = XLSX.write(wb, { type: 'array', bookType: 'xlsx' });
    const regs = await loadRegistrations(new File([bytes], 'dangky.xlsx'));
    expect(regs).toEqual([{ studentId: '0123', courseId: 'IT001' }]);
  });

  it('từ chối đuôi khác, file rỗng, chưa chọn file', async () => {
    await expect(loadRegistrations(new File(['x'], 'data.txt'))).rejects.toThrow(/Chỉ nhận file .csv hoặc .xlsx/);
    await expect(loadRegistrations(new File([], 'a.csv'))).rejects.toThrow(/rỗng/);
    await expect(loadRegistrations(undefined)).rejects.toThrow(/Chưa chọn file/);
  });
});
