import { describe, it, expect } from 'vitest';
import { readFileSync } from 'node:fs';
import * as XLSX from 'xlsx';
import { parseRegistrationsCsv } from '../src/core/dataLoader.js';
import { buildGraph } from '../src/core/graphBuilder.js';
import { welshPowell } from '../src/core/welshPowell.js';
import { dsatur } from '../src/core/dsatur.js';
import { checkScheduleByStudent, checkRooms } from '../src/core/validator.js';
import { compareAlgorithms, lowerBound, upperBound, greedyClique, improvementPercent } from '../src/core/compare.js';
import { lookupStudent } from '../src/core/lookup.js';
import { buildSchedule, slotSummary } from '../src/core/scheduler.js';
import { validateConfig, configToJson, configFromJson, examDates, isValidDate } from '../src/core/constraints.js';
import { exportSchedule, scheduleToCsv } from '../src/core/exporter.js';
import { generateRegistrations } from './helpers/randomData.js';

const fixture = (n) => readFileSync(new URL(`./fixtures/${n}`, import.meta.url), 'utf8');
const regsSmall = () => parseRegistrationsCsv(fixture('small.csv'));
const baseConfig = (over = {}) => ({
  startDate: '2026-12-07', // thứ Hai
  slotsPerDay: 3,
  slotTimes: ['07:30', '09:30', '13:30'],
  rooms: [{ id: 'A101', capacity: 3 }, { id: 'A102', capacity: 2 }],
  holidays: [],
  skipSundays: true,
  maxExamsPerDay: null,
  ...over,
});

describe('compare.js', () => {
  it('cận dưới, cận trên của bộ nhỏ', () => {
    const g = buildGraph(regsSmall());
    expect(lowerBound(g)).toBe(4);
    expect(greedyClique(g).sort()).toEqual(['CTDL', 'GT', 'LTDT', 'TRR']);
    expect(upperBound(g)).toBe(5);
    expect(upperBound(new Map())).toBe(0);
  });
  it('compareAlgorithms: kết quả hợp lệ, nằm giữa hai cận', () => {
    for (const regs of [regsSmall(), generateRegistrations(7, { students: 800, courses: 80, coursesPerStudent: [2, 5] })]) {
      const g = buildGraph(regs);
      const cmp = compareAlgorithms(g, { repeat: 3 });
      expect(cmp.results.map((r) => r.name)).toEqual(['Welsh-Powell', 'DSATUR']);
      for (const r of cmp.results) {
        expect(r.valid).toBe(true);
        expect(r.colorCount).toBeGreaterThanOrEqual(cmp.lowerBound);
        expect(r.colorCount).toBeLessThanOrEqual(cmp.upperBound);
        expect(r.timeMs).toBeGreaterThanOrEqual(0);
      }
    }
  });
  it('cùng seed cho cùng dữ liệu và cùng số màu', () => {
    const opt = { students: 300, courses: 40, coursesPerStudent: 4 };
    expect(generateRegistrations(5, opt)).toEqual(generateRegistrations(5, opt));
    expect(generateRegistrations(5, opt)).not.toEqual(generateRegistrations(6, opt));
    const a = compareAlgorithms(buildGraph(generateRegistrations(5, opt)), { repeat: 1 });
    const b = compareAlgorithms(buildGraph(generateRegistrations(5, opt)), { repeat: 1 });
    expect(a.results.map((r) => r.colorCount)).toEqual(b.results.map((r) => r.colorCount));
  });
  it('improvementPercent', () => {
    expect(improvementPercent(10, 8)).toBe(20);
  });
});

describe('constraints.js', () => {
  it('kiểm tra cấu hình và báo đủ lỗi', () => {
    expect(() => validateConfig({ startDate: '2026-02-30', slotsPerDay: 0, rooms: [] })).toThrow(/Ngày bắt đầu[\s\S]*Số ca[\s\S]*ít nhất một phòng/);
    expect(isValidDate('2026-12-07')).toBe(true);
  });
  it('lưu và đọc cấu hình bằng JSON', () => {
    const cfg = validateConfig(baseConfig({ holidays: ['2026-12-08'] }));
    expect(configFromJson(configToJson(cfg))).toEqual(cfg);
    expect(() => configFromJson('{oops')).toThrow(/JSON/);
  });
  it('ngày thi bỏ Chủ nhật và ngày nghỉ', () => {
    const cfg = validateConfig(baseConfig({ startDate: '2026-12-11', holidays: ['2026-12-14'] })); // thứ Sáu
    expect(examDates(cfg, 3)).toEqual(['2026-12-11', '2026-12-12', '2026-12-15']);
  });
});

describe('scheduler.js', () => {
  it('bộ nhỏ: 4 màu, 3 ca/ngày → 2 ngày, không ai trùng ca, phòng hợp lệ', () => {
    const regs = regsSmall();
    const colors = dsatur(buildGraph(regs));
    const cfg = baseConfig({ rooms: [{ id: 'A101', capacity: 10 }, { id: 'A102', capacity: 10 }, { id: 'A103', capacity: 10 }, { id: 'A104', capacity: 10 }] });
    const { schedule, warnings, days, periods } = buildSchedule(colors, regs, cfg);
    expect(schedule).toHaveLength(8);
    expect(periods).toBe(4);
    expect(days).toBe(2);
    expect(warnings).toEqual([]);
    expect(checkScheduleByStudent(schedule, regs).valid).toBe(true);
    expect(checkRooms(schedule, cfg.rooms).valid).toBe(true);
    expect(new Set(schedule.map((e) => e.date))).toEqual(new Set(['2026-12-07', '2026-12-08']));
  });
  it('7 màu, 3 ca/ngày → 3 ngày; màu i vào ngày ⌊i/3⌋, ca (i mod 3) + 1', () => {
    const colors = new Map(Array.from({ length: 7 }, (_, i) => [`M${i}`, i]));
    const regs = [...colors.keys()].map((c) => ({ studentId: 'SV1', courseId: c }));
    const { schedule, days } = buildSchedule(colors, regs, baseConfig());
    expect(days).toBe(3);
    const m6 = schedule.find((e) => e.course === 'M6');
    expect([m6.date, m6.slot]).toEqual(['2026-12-09', 1]);
  });
  it('môn đông hơn một phòng được chia nhiều phòng', () => {
    const colors = new Map([['BIG', 0]]);
    const regs = Array.from({ length: 5 }, (_, i) => ({ studentId: `S${i}`, courseId: 'BIG' }));
    const { schedule } = buildSchedule(colors, regs, baseConfig());
    expect(schedule[0].rooms.sort()).toEqual(['A101', 'A102']);
  });
  it('thiếu phòng: tách ca phụ ngay sau ca đó, các ca sau lùi một bậc, có cảnh báo', () => {
    // Màu 0 có hai môn 3 SV, chỉ có 1 phòng 3 chỗ + 1 phòng 2 chỗ → một môn sang ca phụ.
    const colors = new Map([['X', 0], ['Y', 0], ['Z', 1]]);
    const regs = [];
    for (let i = 0; i < 3; i++) regs.push({ studentId: `a${i}`, courseId: 'X' }, { studentId: `b${i}`, courseId: 'Y' });
    regs.push({ studentId: 'a0', courseId: 'Z' });
    const { schedule, warnings, periods } = buildSchedule(colors, regs, baseConfig());
    expect(periods).toBe(3);
    const at = Object.fromEntries(schedule.map((e) => [e.course, e.period]));
    expect(at).toEqual({ X: 0, Y: 1, Z: 2 });
    expect(schedule.find((e) => e.course === 'Y').extra).toBe(true);
    expect(warnings.some((w) => w.includes('Y') && w.includes('ca phụ'))).toBe(true);
    expect(checkScheduleByStudent(schedule, regs).valid).toBe(true);
    expect(checkRooms(schedule, baseConfig().rooms).valid).toBe(true);
  });
  it('báo lỗi khi môn đông hơn tổng sức chứa', () => {
    const colors = new Map([['HUGE', 0]]);
    const regs = Array.from({ length: 6 }, (_, i) => ({ studentId: `S${i}`, courseId: 'HUGE' }));
    expect(() => buildSchedule(colors, regs, baseConfig())).toThrow(/không đủ cho môn: HUGE \(6 SV\)/);
  });
  it('ràng buộc mềm: sắp màu giảm số SV thi quá 2 môn/ngày', () => {
    // SV1 học màu 0,1,2; SV2 học màu 3,4,5. Thứ tự mặc định gây quá tải; sắp lại thì không.
    const colors = new Map([['A', 0], ['B', 1], ['C', 2], ['D', 3], ['E', 4], ['F', 5]]);
    const regs = ['A', 'B', 'C'].map((c) => ({ studentId: 'SV1', courseId: c }))
      .concat(['D', 'E', 'F'].map((c) => ({ studentId: 'SV2', courseId: c })));
    const big = { rooms: [{ id: 'P1', capacity: 50 }, { id: 'P2', capacity: 50 }] };
    expect(buildSchedule(colors, regs, baseConfig({ ...big, maxExamsPerDay: null })).overload.students).toBe(0);
    const noOrder = buildSchedule(colors, regs, baseConfig({ ...big, maxExamsPerDay: 99 }));
    const ordered = buildSchedule(colors, regs, baseConfig({ ...big, maxExamsPerDay: 2 }));
    expect(noOrder.colorOrder).toEqual([0, 1, 2, 3, 4, 5]);
    expect(ordered.overload.students).toBe(0);
    expect(checkScheduleByStudent(ordered.schedule, regs).valid).toBe(true);
  });
  it('bộ lớn: lịch hợp lệ với cả hai thuật toán', () => {
    const regs = parseRegistrationsCsv(fixture('large.csv'));
    const g = buildGraph(regs);
    const rooms = Array.from({ length: 20 }, (_, i) => ({ id: `P${i + 1}`, capacity: 60 }));
    for (const colors of [welshPowell(g), dsatur(g)]) {
      const { schedule } = buildSchedule(colors, regs, baseConfig({ rooms, maxExamsPerDay: 2 }));
      expect(checkScheduleByStudent(schedule, regs).valid).toBe(true);
      expect(checkRooms(schedule, rooms).valid).toBe(true);
      expect(slotSummary(schedule).reduce((s, x) => s + x.courses, 0)).toBe(190);
    }
  });
});

describe('validator.checkScheduleByStudent', () => {
  it('bắt lịch cố tình xếp trùng ca và môn bị thiếu', () => {
    const regs = regsSmall();
    const schedule = [...new Set(regs.map((r) => r.courseId))].filter((c) => c !== 'TA')
      .map((c) => ({ course: c, date: '2026-12-07', slot: 1, rooms: [] }));
    const r = checkScheduleByStudent(schedule, regs);
    expect(r.valid).toBe(false);
    expect(r.conflicts.some((c) => c.studentId === 'SV01')).toBe(true);
    expect(r.missing).toEqual(['TA']);
  });
});

describe('lookup.js', () => {
  const regs = regsSmall();
  const cfg = baseConfig({ rooms: [{ id: 'P1', capacity: 50 }, { id: 'P2', capacity: 50 }, { id: 'P3', capacity: 50 }] });
  const { schedule } = buildSchedule(dsatur(buildGraph(regs)), regs, cfg);
  it('tra đúng các môn của sinh viên, sắp theo ngày và ca; nhận mã viết thường', () => {
    const rows = lookupStudent(schedule, regs, ' sv01 ');
    expect(rows.map((r) => r.course).sort()).toEqual(['CTDL', 'GT', 'TRR']);
    for (let i = 1; i < rows.length; i++) expect(rows[i].period).toBeGreaterThan(rows[i - 1].period);
  });
  it('báo rõ khi mã không tồn tại hoặc để trống', () => {
    expect(() => lookupStudent(schedule, regs, 'SV99')).toThrow(/Không tìm thấy sinh viên có mã SV99/);
    expect(() => lookupStudent(schedule, regs, '  ')).toThrow(/Hãy nhập mã/);
  });
});

describe('exporter.js', () => {
  const schedule = [{ course: 'GT', date: '2026-12-07', slot: 1, time: '07:30', rooms: ['A101', 'A102'], students: 40 }];
  it('CSV có BOM, phòng ghép bằng dấu phẩy trong nháy kép', () => {
    const csv = scheduleToCsv(schedule);
    expect(csv.startsWith('﻿Mã môn,Ngày thi')).toBe(true);
    expect(csv).toContain('GT,2026-12-07,1,07:30,"A101, A102",40');
  });
  it('xuất Blob CSV và XLSX đọc lại được', async () => {
    const csvBlob = await exportSchedule(schedule, 'csv');
    expect(csvBlob.type).toMatch(/text\/csv/);
    const xBlob = await exportSchedule(schedule, 'xlsx');
    const wb = XLSX.read(new Uint8Array(await xBlob.arrayBuffer()), { type: 'array' });
    const rows = XLSX.utils.sheet_to_json(wb.Sheets.LichThi, { header: 1 });
    expect(rows[1]).toEqual(['GT', '2026-12-07', 1, '07:30', 'A101, A102', 40]);
    await expect(exportSchedule(schedule, 'pdf')).rejects.toThrow(/không được hỗ trợ/);
  });
});
