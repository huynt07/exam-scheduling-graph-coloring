/**
 * Sinh tests/fixtures/large.csv một lần rồi commit file kết quả (bộ lớn cố định).
 * Chạy: node tests/fixtures/generateLarge.mjs
 * Dùng bộ sinh đồng dư tuyến tính (LCG) với seed cố định để ai chạy lại cũng ra đúng file đó.
 * Cấu trúc: 8 ngành, mỗi ngành 20 môn riêng + 30 môn chung; mỗi sinh viên học 3–4 môn ngành
 * và 1–2 môn chung, giống dữ liệu thật hơn chọn môn hoàn toàn ngẫu nhiên.
 */
import { writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

let state = 20241118;
const rand = () => (state = (state * 1103515245 + 12345) % 2147483648) / 2147483648;
const pick = (arr, k) => {
  const copy = [...arr];
  const out = [];
  while (out.length < k) out.push(copy.splice(Math.floor(rand() * copy.length), 1)[0]);
  return out;
};

const MAJORS = 8, PER_MAJOR = 20, COMMON = 30, STUDENTS = 3000;
const common = Array.from({ length: COMMON }, (_, i) => `CH${String(i + 1).padStart(3, '0')}`);
const lines = ['studentId,courseId'];
for (let s = 1; s <= STUDENTS; s++) {
  const id = `SV${String(s).padStart(5, '0')}`;
  const major = (s - 1) % MAJORS;
  const majorCourses = Array.from({ length: PER_MAJOR },
    (_, i) => `N${major + 1}M${String(i + 1).padStart(2, '0')}`);
  const courses = [...pick(majorCourses, 3 + Math.floor(rand() * 2)), ...pick(common, 1 + Math.floor(rand() * 2))];
  for (const c of courses) lines.push(`${id},${c}`);
}
const out = fileURLToPath(new URL('./large.csv', import.meta.url));
writeFileSync(out, lines.join('\n') + '\n');
console.log(`Đã ghi ${lines.length - 1} dòng vào ${out}`);
