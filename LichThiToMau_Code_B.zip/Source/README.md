# Xếp lịch thi bằng tô màu đồ thị — mã nguồn

Ứng dụng web chạy trên trình duyệt, xếp lịch thi tập trung bằng hai thuật toán tô màu đồ thị
(Welsh-Powell, DSATUR). Môn thi là đỉnh, hai môn có sinh viên học chung thì nối cạnh, mỗi màu là một ca thi.

Tài liệu này dành cho **nhóm phát triển**. Người dùng cuối chỉ cần file `Release/index.html`
(xem hướng dẫn sử dụng trong `Document/`).

## Cài đặt

Cần Node.js 18 trở lên (khuyên dùng bản LTS mới nhất).

```bash
cd Source
npm install
```

SheetJS (`xlsx`) được cài từ `https://cdn.sheetjs.com` theo khuyến nghị của SheetJS, vì bản trên npm
đã cũ. Nếu mạng chặn trang này, tạm đổi dòng `xlsx` trong `package.json` thành `"xlsx": "0.18.5"`,
nhưng **không commit** thay đổi đó.

## Lệnh thường dùng

| Lệnh | Việc |
|---|---|
| `npm run dev` | Chạy bản phát triển tại `http://localhost:5173` |
| `npm test` | Chạy toàn bộ test Vitest một lần |
| `npm run test:watch` | Chạy test và tự chạy lại khi sửa code |
| `npm run build` | Build ra **một file** `../Release/index.html` (vite-plugin-singlefile) |
| `npm run experiment` | Chạy thực nghiệm so sánh hai thuật toán (mục 4.3), ghi `tests/experiment-result.csv` |

Bản build mở được bằng cách bấm đúp trên Chrome hoặc Edge, không cần cài Node.js.

## Cấu trúc thư mục

```
Source/
├── index.html            trang chính (E)
├── css/style.css         giao diện (E)
├── src/
│   ├── core/             xử lý dữ liệu và thuật toán, KHÔNG dùng document/window
│   │   ├── dataLoader.js     đọc CSV/Excel, kiểm tra dữ liệu nhập (A)
│   │   ├── graphBuilder.js   dựng đồ thị xung đột (A)
│   │   ├── welshPowell.js, validator.js, compare.js (B)
│   │   ├── dsatur.js, lookup.js (C)
│   │   └── scheduler.js, constraints.js, exporter.js (D)
│   └── ui/
│       ├── main.js, visualizer.js, statsPanel.js (E)
│       └── fileLoader.js     đọc File người dùng chọn (A)
└── tests/
    ├── fixtures/         dữ liệu chỉ dùng nội bộ để kiểm thử
    ├── helpers/randomData.js   sinh dữ liệu có seed cho test/thực nghiệm (C)
    ├── experiment.mjs          thực nghiệm cho mục 4.3 (C)
    └── *.test.js               test Vitest của từng module
```

Ứng dụng **không** nạp sẵn dữ liệu nào. Các file trong `tests/` không được import từ `src/`.

## Định dạng dữ liệu đầu vào

File CSV hoặc Excel (.xlsx) có dòng tiêu đề và hai cột:

| Cột | Tên được chấp nhận (không phân biệt hoa thường, dấu, khoảng trắng) |
|---|---|
| Mã sinh viên | `studentId`, `MSSV`, `Mã SV`, `Mã sinh viên` |
| Mã môn | `courseId`, `Mã môn`, `Mã môn học` |

- Mỗi dòng là một lượt đăng ký; sinh viên học nhiều môn thì xuất hiện ở nhiều dòng.
- CSV: UTF-8, có hoặc không có BOM, phân cách bằng `,` hoặc `;`. Cột thừa được bỏ qua.
- Excel: chỉ đọc sheet đầu tiên; mọi ô đọc thành chuỗi nên mã `0123` giữ số 0 đầu
  (ô phải được định dạng Text trong Excel, nếu không Excel đã tự xóa số 0 khi nhập).
- Mã được cắt khoảng trắng và viết hoa. Dòng trống bị bỏ qua.
- Lỗi được báo kèm số dòng: thiếu cột, ô trống, đăng ký trùng, file rỗng, sheet rỗng.

## Fixture kiểm thử

| File | Nội dung |
|---|---|
| `small.csv` | 10 sinh viên, 8 môn, 19 dòng; đồ thị 11 cạnh, có K4 và một đỉnh cô lập (TA) |
| `small.expected.json` | Danh sách kề của bộ nhỏ lập bằng tay |
| `vietnamese.csv` | BOM, dấu `;`, cột `MSSV`/`Mã môn`, khoảng trắng thừa, mã có số 0 đầu |
| `large.csv` | 3.000 sinh viên, 190 môn, 14.897 dòng; sinh bằng `generateLarge.mjs` (seed cố định) |

## Quy ước

- Tên file, hàm, biến: camelCase tiếng Anh. Comment và JSDoc: tiếng Việt.
- Thứ tự phá hòa dùng chung: `compareIds` trong `graphBuilder.js` (so sánh theo mã ký tự,
  không dùng `localeCompare` để kết quả giống nhau trên Node.js và trình duyệt).
- Git: mỗi người một nhánh `feature/<tên>`; `main` chỉ nhận code qua Pull Request.
